/* Notification UI uses the supplied HTML design and its HA bindings. */
export {mountNotifications} from './companion-notifications-design.js?v=0.2.0&rev=20261115-23';
