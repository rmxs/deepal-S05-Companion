/* ───────────────────────── "Energy" sheet (lazy module) ─────────────────────────
 * Loaded ONLY when the user taps the battery tile (dist/energy/energy.js); the card's main file does not contain it.
 * It reads the HA history (history/history_during_period) for battery, AC/DC charging current, odometer and power_status.
 * It writes nothing and sends no commands to the vehicle. Sources: src/energy/*.js — build: scripts/build.sh */
(function () {
"use strict";
const EN = (window.__DEEPAL_COMPANION_ENERGY = window.__DEEPAL_COMPANION_ENERGY || {});
let infoOpen = false; /* the calculation notes at the bottom of the Energy window are folded until the user asks */
let K = null; /* shared card tools: { esc, T, ico, I18N, resolveId } — given by the card in init() */
const fill = (s, a) => String(s).replace(/\{(\d+)\}/g, (m, i) => (a[i] ?? ""));
const T = (s, ...a) => (K ? K.T(s, ...a) : fill(s, a));
const ico = (n, c) => (K ? K.ico(n, c) : "");
const tError = (m) => (K && K.tError ? K.tError(m) : m);
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
/* ───── Data: history → series → charges, drives, daily figures ───── */
const DAYS_BACK = 5, CHG_A = 0.5, GAP = 15 * 60e3, MIN_CHG = 8 * 60e3, DRV_GAP = 12 * 60e3, DEF_KWH = 18.4;
const ts = (v) => { if (typeof v === "number") return v > 1e11 ? v : v * 1000; const n = Date.parse(v); return Number.isFinite(n) ? n : NaN; };
const num = (s) => { if (s === null || s === undefined || s === "" || s === "unknown" || s === "unavailable") return NaN; const n = Number(s); return Number.isFinite(n) ? n : NaN; };
/* HA history (minimal_response) → [[t, state]] sorted */
function rowsOf(list) {
  const out = [];
  for (const r of Array.isArray(list) ? list : []) {
    if (!r) continue;
    const t = ts(r.lu ?? r.lc ?? r.last_updated ?? r.last_changed), s = r.s !== undefined ? r.s : r.state;
    if (Number.isFinite(t)) out.push([t, s]);
  }
  return out.sort((a, b) => a[0] - b[0]);
}
const numSeries = (rows) => rows.map(([t, s]) => [t, num(s)]).filter((p) => Number.isFinite(p[1]));
/* last known value at time t (before the first reading: the first one) */
function at(ser, t) {
  if(!ser.length)return NaN;
  let lo=0,hi=ser.length;
  while(lo<hi){const mid=(lo+hi)>>>1;if(ser[mid][0]<=t)lo=mid+1;else hi=mid;}
  const value=lo?ser[lo-1][1]:NaN;
  return Number.isFinite(value)?value:ser[0][1];
}
const dayKey = (t,timezone) => energyDayStart(0,timezone,t);

/* Charges from the AC/DC currents. The "charging" binary_sensor is not reliable on this vehicle, while the current is.
   unavailable/unknown values do NOT count as 0: we keep the previous state up to GAP. Gaps ≤ GAP are joined. */
function chargeSegments(acRows, dcRows, now, liveOk = true) {
  const A = acRows.map(([t, s]) => [t, num(s)]), D = dcRows.map(([t, s]) => [t, num(s)]);
  const times = [...new Set([...A, ...D].map((p) => p[0]))].sort((a, b) => a - b);
  if (!times.length) return [];
  const states=new Map();let ai=0,di=0,a=NaN,d=NaN;
  for(const t of times){
    while(ai<A.length&&A[ai][0]<=t)a=A[ai++][1];
    while(di<D.length&&D[di][0]<=t)d=D[di++][1];
    const validA=Number.isFinite(a),validD=Number.isFinite(d);
    states.set(t,validA||validD?(validA&&a>CHG_A)||(validD&&d>CHG_A):null);
  }
  const state=t=>states.get(t);
  const iv = []; let prev = false;
  times.forEach((t, i) => {
    const e = i + 1 < times.length ? times[i + 1] : now, st = state(t);
    if (st === null) {
      const keep = Math.min(e - t, GAP);
      if (prev && keep > 0) iv.push([t, t + keep, true]);
      if (e - t > keep) iv.push([t + keep, e, false]);
      if (e - t > GAP) prev = false;
    } else { iv.push([t, e, st]); prev = st; }
  });
  const segs = [];
  for (const [s, e, on] of iv) {
    if (!on || e <= s) continue;
    const last = segs[segs.length - 1];
    if (last && s - last.e <= GAP) last.e = Math.max(last.e, e); else segs.push({ s, e });
  }
  /* DC only if the DC current is active for at least half of the charge; a momentary sensor spike does not make it DC */
  const prefix=[0];
  for(let i=0;i<D.length;i++)prefix.push(prefix[i]+(D[i][1]>CHG_A?Math.max(0,(i+1<D.length?D[i+1][0]:now)-D[i][0]):0));
  const dcArea=t=>{
    let lo=0,hi=D.length;while(lo<hi){const mid=(lo+hi)>>>1;if(D[mid][0]<=t)lo=mid+1;else hi=mid;}
    if(!lo)return 0;const i=lo-1;
    return prefix[i]+(D[i][1]>CHG_A?Math.max(0,Math.min(t,now)-D[i][0]):0);
  };
  const dcTime=(s,e)=>dcArea(e)-dcArea(s);
  return segs.filter((g) => g.e - g.s >= MIN_CHG).map((g) => ({ s: g.s, e: g.e, dc: dcTime(g.s, g.e) >= (g.e - g.s) / 2, live: liveOk && g.e >= now - 3 * 60e3 && state(times[times.length - 1]) !== false }));
}
/* Drives: periods when the car is on (power_status = on) and the odometer increases; without power_status: from odometer increases */
function driveSegments(powRows, odo, now) {
  const km = (s, e) => Math.max(0, at(odo, e) - at(odo, s));
  let out = [];
  if (powRows.length) {
    let st = null;
    for (let i = 0; i < powRows.length; i++) {
      const on = powRows[i][1] === "on";
      if (on && st === null) st = powRows[i][0];
      if (!on && st !== null && powRows[i][1] !== "unavailable" && powRows[i][1] !== "unknown") { out.push({ s: st, e: powRows[i][0] }); st = null; }
    }
    if (st !== null) out.push({ s: st, e: now });
  } else {
    for (let i = 1; i < odo.length; i++) if (odo[i][1] > odo[i - 1][1]) {
      const l = out[out.length - 1], s = Math.max(odo[i - 1][0], odo[i][0] - DRV_GAP);
      if (l && s - l.e <= DRV_GAP) l.e = odo[i][0]; else out.push({ s, e: odo[i][0] });
    }
  }
  return out.map((d) => ({ s: d.s, e: d.e, km: km(d.s, d.e) })).filter((d) => d.km >= 0.2 && d.km < 800);
}
/* Petrol sensor: we ignore momentary "holes" (e.g. 68 → 0 → 68 within a few minutes) that would otherwise count as huge consumption */
function despike(ser) {
  return ser.filter((p, i) => {
    const a = ser[i - 1], n = ser[i + 1]; if (!a || !n) return true;
    return !(p[1] < a[1] - 8 && n[0] - p[0] <= 15 * 60e3 && Math.abs(n[1] - a[1]) <= 2);
  });
}
/* All together for the sheet. cap = battery capacity in kWh (setting) */
function model(raw, now, cap, t0in, nDays = DAYS_BACK, liveOk = true, timezone) {
  const batt = despike(numSeries(raw.batt)), odo = numSeries(raw.odo);
  const chg = chargeSegments(raw.ac, raw.dc, now, liveOk);
  chg.forEach((g) => {
    g.from = at(batt, g.s);
    const endT = g.live ? now : Math.min(now, g.e + 10 * 60e3); g.to = at(batt, endT);
    g.kwh = cap > 0 && Number.isFinite(g.from) && Number.isFinite(g.to) && g.to > g.from ? (g.to - g.from) / 100 * cap : null;
  });
  const drv = driveSegments(raw.pow, odo, now);
  const days = [], t0 = t0in !== undefined ? t0in : energyDayStart(-(nDays-1),timezone,now);
  for (let i = 0; i < nDays; i++) { const s = energyDayStart(i,timezone,t0); days.push({ t: s, key: dayKey(s,timezone), km: 0, kwh: 0, n: 0 }); }
  drv.forEach((d) => { const x = days.find((y) => y.key === dayKey(d.s,timezone)); if (x) x.km += d.km; });
  chg.forEach((g) => { const x = days.find((y) => y.key === dayKey(g.s,timezone)); if (x) { x.n++; if (g.kwh) x.kwh += g.kwh; } });
  // Keep a low-water baseline across drives: small rebounds must not be consumed twice.
  // Estimated battery energy discharged during drives; charging starts a new baseline.
  let batteryBase = NaN;
  for (let i = 0; i < batt.length; i++) {
    const [t, value] = batt[i];
    if (value < 0 || value > 100) continue;
    const charging = chg.some((g) => t >= g.s && t <= g.e);
    if (!Number.isFinite(batteryBase) || charging || value >= batteryBase + 2) { batteryBase = value; continue; }
    if (value >= batteryBase) continue;
    const next = batt[i + 1];
    if (batteryBase - value > 8 && (!next || next[1] > value + 2)) continue;
    const drop = batteryBase - value; batteryBase = value;
    const drive = drv.find((d, j) => t > d.s && t <= Math.min(d.e + 10 * 60e3, j + 1 < drv.length ? drv[j + 1].s : Infinity));
    if (!drive || !(cap > 0)) continue;
    const day = days.find((d) => d.key === dayKey(t,timezone));
    if (day) day.batteryUsed = (day.batteryUsed || 0) + drop * cap / 100;
  }
  const fuel = despike(numSeries(raw.fuel).filter((p) => p[1] >= 0 && p[1] <= 100));
  const volume=despike(numSeries(raw.volume||[]).filter(p=>p[1]>=0));
  let fuelUsed = false, base = volume.length ? volume[0][1] : NaN;
  drv.forEach((d) => { d.fuel = 0; });
  for (let i = 1; i < volume.length; i++) {
    const [t, value] = volume[i], next = volume[i + 1];
    // A rise of at least 5 litres is a refill only when another reading supports it.
    if (value >= base + 5) {
      if (next && next[1] >= value - 2) base = value;
      continue;
    }
    if (value >= base) continue;
    // Large drops remain provisional until a second low reading confirms them.
    if (base - value > 8 && (!next || next[1] > value + 2)) continue;
    const drop = base - value; base = value;
    const d = drv.find((d, j) => t > d.s && t <= Math.min(d.e + 10 * 60e3, j + 1 < drv.length ? drv[j + 1].s : Infinity));
    if (!d) continue;
    d.fuel += drop; fuelUsed = true;
    const day = days.find((x) => x.key === dayKey(t,timezone));
    if (day) day.fuel = (day.fuel || 0) + drop;
  }
  return { batt, chg, drv, days, t0, now, nDays, timezone, fuel, fuelUsed, hasData: batt.length > 0 };
}
/* ───── The sheet: current state, 5-day battery curve, per day, list of charges ───── */
const PCSS = `
.enpanel .cc-location-details{transition:transform .18s cubic-bezier(.2,.8,.2,1),box-shadow .18s}.enpanel .cc-location-details.drag{transition:none;z-index:5;position:relative;cursor:grabbing;box-shadow:0 10px 26px #0007;background:var(--ds-card,var(--card-background-color))}.enpanel .cc-profiles.dragging{user-select:none;-webkit-user-select:none}.enpanel .cc-profiles.dragging .cc-grip{cursor:grabbing!important}
.enpanel{--energy-charge:rgb(var(--ds-ac,var(--ds-ok,52,211,153)));--energy-drive:light-dark(#2457c5,#82acff);--energy-parked:light-dark(#8793a1,#8693a5);--energy-fuel:light-dark(#a85a06,#ffcb66)}
.enpanel .cc-removed-profile{display:block;color:rgb(var(--ds-warn));font-size:11px;line-height:1.5;margin-top:4px}.enpanel .cc-removed-profile ha-icon{--mdc-icon-size:16px;vertical-align:middle}
.enpanel .en-cost-tabs {display:flex;gap:8px;margin-bottom:10px}.enpanel .en-cost-tabs button {border:1px solid var(--ds-line);border-radius:10px;padding:8px 12px;background:transparent;color:var(--ds-fg);font:inherit;font-size:12px;cursor:pointer}.enpanel .en-cost-tabs button[aria-pressed=true] {background:rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.14);border-color:rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.4)}.enpanel .en-cost-heading h3 {font-size:16px;margin:6px 0}.enpanel .en-cost-heading small {font-size:11px;color:var(--ds-fg2)}
.enpanel .cc-summary {display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px;border:1px solid var(--ds-line);border-radius:16px;background:rgba(var(--ds-info),.045)}
.enpanel .cc-summary small {display:block;color:var(--ds-fg2);font-size:11px;line-height:1.5}
.enpanel .cc-summary b {display:block;font-size:23px;font-variant-numeric:tabular-nums}
.enpanel .cc-button {border:1px solid var(--cp-off-line);padding:8px 14px;background:var(--cp-off-bg);color:var(--ds-fg);font:inherit;min-height:var(--cp-ctl-h);border-radius:var(--cp-ctl-r);font-size:13px;font-weight:600;cursor:pointer}
.enpanel .cc-button.primary {background:rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.16);border-color:rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.35)}
.enpanel .cc-button:disabled {opacity:.5}
.enpanel .cc-close {width:var(--cp-ctl-h,40px);min-width:var(--cp-ctl-h,40px);padding:0;display:inline-grid;place-items:center} .enpanel .cc-close .i {--is:18px}
/* Icons are SVG strokes. The card's global .i rule (stroke: currentColor) is not in this sheet when it opens in the panel, so the X drew nothing: give the sheet the same rule. */
.enpanel .i {width:var(--is,20px);height:var(--is,20px);fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round;flex:none}
.enpanel .cc-button.danger{color:rgb(var(--ds-bad));border-color:rgba(var(--ds-bad),.35);background:rgba(var(--ds-bad),.08);margin-top:10px}
.enpanel .cc-delete-confirm{border:1px solid rgba(var(--ds-bad),.35);border-radius:12px;padding:12px;margin-top:12px}.enpanel .cc-delete-confirm p{font-size:12px;line-height:1.5;margin:0 0 8px}
.enpanel .cc-name-field{position:relative}.enpanel .cc-name-options{position:absolute;top:100%;left:0;right:0;z-index:5;padding:4px;background:var(--ds-card);border:1px solid var(--ds-line);border-radius:11px;box-shadow:0 8px 24px #0004}.enpanel .cc-name-options[hidden]{display:none}.enpanel .cc-name-options button{display:block;width:100%;min-height:42px;border:0;border-radius:7px;padding:8px 10px;text-align:left;font:inherit;color:var(--ds-fg);background:transparent}.enpanel .cc-name-options button:hover,.enpanel .cc-name-options button[aria-selected=true]{background:var(--cp-on-bg);color:var(--cp-accent)}
.enpanel .cc-editor:empty {display:none}
.enpanel .cc-editor form {border:1px solid var(--cp-off-line);border-radius:var(--cp-block-r);padding:var(--cp-block-p);background:var(--cp-block-bg)}
.enpanel .cc-editor-head,.enpanel .cc-actions {display:flex;align-items:center;justify-content:space-between;gap:8px}
.enpanel .cc-editor-head b {font-size:14px}
.enpanel .cc-grid {display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin:12px 0}
.enpanel .cc-field {display:flex;flex-direction:column;gap:6px;font-size:11px;color:var(--ds-fg2);min-width:0}
.enpanel .cc-field input,.enpanel .cc-field select {box-sizing:border-box;width:100%;min-width:0;border:1px solid var(--ds-line);border-radius:var(--cp-ctl-r);background:var(--ds-card,#202226);color:var(--ds-fg);font:inherit;font-size:13px;padding:9px;outline-offset:2px}
.enpanel .cc-check {display:flex;align-items:center;gap:7px;font-size:12px}
.enpanel .cc-check input {accent-color:rgb(var(--ds-ac,var(--ds-ok,52,211,153)));width:17px;height:17px}
.enpanel .cc-profile {border:1px solid var(--ds-line);border-radius:12px;margin:12px 0;padding:8px 12px}
.enpanel .cc-profile legend {font-size:12px;color:var(--ds-fg)}
.enpanel .cc-info{padding:10px 12px;border:1px solid rgba(var(--ds-info),.3);border-radius:10px;background:rgba(var(--ds-info),.08);font-size:11px;line-height:1.5}.enpanel .cc-info[hidden]{display:none}
.enpanel .cc-hint {font-size:11px;line-height:1.5;color:var(--ds-fg2);margin:9px 0}
.enpanel .cc-session-row{display:grid;grid-template-columns:minmax(0,1fr) auto;align-items:stretch;gap:8px;margin:6px 0 18px}.enpanel .cc-session-row .cc-curve{width:56px;min-width:56px;height:auto;align-self:stretch;padding:0;border-radius:14px;border:1px solid var(--cp-off-line,var(--ds-line));background:var(--cp-off-bg,rgba(127,127,127,.06))}.enpanel .cc-session-row .cc-curve .i{--is:22px}.enpanel .cc-session-row .cc-curve:hover{background:var(--cp-on-bg,rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.12))}.enpanel .cc-session-row .cc-session{margin:0}.enpanel .cc-curve{display:flex;align-items:center;justify-content:center;gap:5px;min-height:44px;color:rgb(var(--ds-ac,var(--ds-ok,52,211,153)))}.enpanel .cc-curve svg{width:18px;height:18px}@media(max-width:380px){.enpanel .cc-curve{flex-direction:column;font-size:10px}}
.enpanel .cc-session {box-sizing:border-box;width:100%;display:flex;align-items:center;justify-content:space-between;gap:14px;border:1px solid var(--ds-line);border-radius:12px;background:rgba(var(--ds-info),.035);padding:12px 14px;color:var(--ds-fg);text-align:left;font:inherit;font-size:12px;cursor:pointer;margin:6px 0 18px}
.enpanel .cc-session .cc-location-name{display:block;font-size:12px;font-weight:600;margin-bottom:4px}.enpanel .cc-session>span:first-child{min-width:0;overflow-wrap:anywhere}
.enpanel .cc-session small {display:block;font-size:10px;line-height:1.6;color:var(--ds-fg2)}
.enpanel .cc-session .cc-price-badge {flex:none;display:flex;align-items:center;gap:10px;padding:8px 10px;border-radius:9px;background:rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.09);color:rgb(var(--ds-ac,var(--ds-ok,52,211,153)))}.enpanel .cc-session b{font-size:14px;white-space:nowrap;font-variant-numeric:tabular-nums}.enpanel .cc-session .cc-price-badge small{font-size:9px}.enpanel .cc-session .cc-price-badge i{font-style:normal;opacity:.65}
.enpanel .en-body.is-period-loading>.dc-loader{visibility:hidden}.enpanel .en-body.is-period-loading{position:relative}.en-period-loader{position:absolute;inset:0;z-index:2;display:grid;place-items:center;border-radius:12px;background:var(--ds-card,#202226);opacity:.94;min-height:120px}.en-period-loader .dc-loader{margin:0}.enpanel .is-period-loading .en-cw>svg{visibility:hidden}.enpanel .is-period-loading .en-cw{position:relative}.enpanel .en-load-error{padding:12px;color:rgb(var(--ds-warn));font-size:12px}
.cc-charts{position:relative;border:1px solid var(--ds-line,var(--divider-color));border-radius:14px;padding:12px;margin:12px 0}.cc-chart-tip{position:absolute;right:12px;top:36px;max-width:calc(100% - 24px);z-index:2;pointer-events:none;padding:7px 10px;border:1px solid var(--ds-line,var(--divider-color));border-radius:10px;background:var(--ds-card,var(--card-background-color));color:var(--ds-fg,var(--primary-text-color));font-size:11px;box-shadow:0 4px 18px #0004}.cc-chart-tip[hidden]{display:none}.cc-chart-heading{font-size:13px;font-weight:600;margin-bottom:10px}.cc-chart-grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.cc-chart{min-width:0}.cc-chart b{font-size:11px}.cc-chart svg{display:block;width:100%;color:var(--ds-fg,var(--primary-text-color))}.cc-charts small{font-size:10px;line-height:1.5;color:var(--ds-fg2,var(--secondary-text-color))}@media(max-width:480px){.cc-chart-grid{grid-template-columns:1fr}}
.enpanel .cc-location {margin:12px 0} .enpanel .cc-advanced {margin:10px 0 14px} .enpanel .cc-advanced summary {font-size:11px;color:var(--ds-fg2);cursor:pointer} .enpanel .cc-day-cost {display:block;font-size:10px;line-height:1.5;color:var(--ds-fg2)}
.enpanel [data-cc-entity-field][hidden],.enpanel .cc-paid[hidden]{display:none}.enpanel .cc-profile-head{display:grid;grid-template-columns:1fr auto;align-items:end;gap:12px}.enpanel .cc-profile-head .cc-check{padding-bottom:10px}.enpanel .cc-actions{margin-top:12px}.enpanel .cc-profile{min-width:0}.enpanel .cc-profiles{min-width:0}
.enpanel .cc-location-details{border:1px solid var(--cp-off-line);border-radius:var(--cp-item-r);background:var(--cp-off-bg);margin:8px 0}.enpanel .cc-loc-ic{flex:none;display:grid;place-items:center;width:38px;height:38px;border-radius:12px;background:var(--cp-on-bg,rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.12));color:var(--cp-accent,rgb(var(--ds-ac,var(--ds-ok,52,211,153))))}.enpanel .cc-loc-ic .i{--is:20px;width:var(--is);height:var(--is);fill:none;stroke:currentColor;stroke-width:1.6;stroke-linecap:round;stroke-linejoin:round}.enpanel .cc-loc-t{flex:1;min-width:0;display:flex;flex-direction:column;gap:2px}.enpanel .cc-loc-t b{font-size:14.5px;font-weight:700;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.enpanel .cc-loc-t em{font-style:normal;font-size:11.5px;color:var(--ds-fg2)}.enpanel .cc-location-details>summary small.cc-loc-p{flex:none;padding:5px 10px;border-radius:999px;font-size:12px;font-weight:700;color:var(--ds-fg);background:var(--cp-off-bg,rgba(127,127,127,.08));border:1px solid var(--cp-off-line,var(--ds-line))}.enpanel .cc-location-details>summary small.cc-loc-p.free{color:var(--cp-accent,rgb(var(--ds-ac,var(--ds-ok,52,211,153))));background:var(--cp-on-bg,rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.12));border-color:var(--cp-on-line,rgba(var(--ds-ac,var(--ds-ok,52,211,153)),.45))}.enpanel .cc-location-details>summary small.cc-loc-p.unset{color:rgb(var(--ds-warn,250,204,21))}.enpanel .cc-location-details>summary{min-height:64px;gap:12px}.enpanel .cc-location-details>summary{display:flex;gap:10px;align-items:center;min-height:48px;padding:10px 12px;cursor:pointer;list-style:none}.enpanel .cc-location-details>summary>span:first-child{flex:1}.enpanel .cc-location-details>summary small{font-size:11px;color:var(--ds-fg2)}.enpanel .cc-location-details>summary::-webkit-details-marker{display:none}.enpanel .cc-location-details .cc-profile{border:0}.enpanel .cc-location-details[open]>summary{border-bottom:1px solid var(--ds-line)}
@media(max-width:420px){.enpanel .cc-grid{gap:9px}.enpanel .cc-summary{padding:10px}.enpanel .cc-profile{padding:6px 8px}}

.enpanel { flex:1 1 auto; min-height:0; overflow-y:auto; overflow-x:hidden; overscroll-behavior:contain; display:flex; flex-direction:column; gap:22px; padding:8px 6px 26px; color: var(--ds-fg); }
.enpanel .en-nav [data-wk]{color:var(--ds-fg,var(--primary-text-color,#eee))}.enpanel .en-nav [data-wk] .i{fill:none;stroke:currentColor;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}.enpanel .en-nav [data-wk] .i path{fill:none;stroke:inherit}
.enpanel .en-nav { display:flex; align-items:center; flex-wrap:wrap; gap:10px; } .enpanel .en-nav .btn { width:44px; height:40px; padding:0; display:grid; place-items:center; } .enpanel .en-nav .btn[disabled] { opacity:.35; cursor:default; pointer-events:none; } .enpanel .en-wk { flex:1; text-align:center; } .enpanel .en-wk b { display:block; font-size:14.5px; font-weight:600; } .enpanel .en-wk small { display:block; margin-top:1px; font-size:12px; color: var(--ds-fg2); } .enpanel .en-lim { flex-basis:100%; text-align:center; }
.enpanel .en-dates { display:flex; align-items:center; gap:8px; margin-left:auto; } .enpanel .en-dates .en-wk { min-width:140px; } .enpanel .en-nav { justify-content:center; padding:10px; border:1px solid var(--ds-line); border-radius:14px; gap:10px; } @media(max-width:480px) { .enpanel .en-dates { margin-left:0; } }
.enpanel .en-body { display:flex; flex-direction:column; gap:20px; }
.enpanel .en-now { border-radius:18px; padding:14px 16px; background: rgba(var(--rgb-primary-text-color, 255,255,255), .045); border:1px solid var(--ds-line); }
.enpanel .en-now.chg { background: rgba(var(--ds-ac,var(--ds-ok,52,211,153)), .12); border-color: rgba(var(--ds-ac,var(--ds-ok,52,211,153)), .35); }
.enpanel .en-st { display:flex; align-items:center; justify-content:space-between; gap:8px; font-size:14.5px; font-weight:600; }
.enpanel .en-st span.s { display:flex; align-items:center; gap:8px; } .enpanel .en-st .i { --is:20px; } .enpanel .en-now.chg .en-st .i { color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); }
.enpanel .en-st small { font-size:12px; font-weight:500; color: var(--ds-fg2); }
.enpanel .en-big { display:flex; align-items:baseline; gap:10px; margin-top:8px; flex-wrap:wrap; } .enpanel .en-big b { font-size:38px; line-height:1; font-weight:600; font-variant-numeric: tabular-nums; } .enpanel .en-big span { font-size:14px; color: var(--ds-fg2); }
.enpanel .en-sub { margin-top:4px; font-size:13px; color: var(--ds-fg2); line-height:1.45; }
.enpanel .en-leg { display:flex; flex-wrap:wrap; gap:6px 14px; align-items:center; margin:0 0 4px; font-size:12px; color: var(--ds-fg2); } .enpanel .en-leg i { display:inline-block; width:10px; height:10px; border-radius:2px; margin-right:5px; vertical-align:-1px; }
.enpanel .en-cw { position:relative; } .enpanel .en-tip { position:absolute; top:2px; z-index:2; pointer-events:none; padding:8px 10px; border-radius:12px; font-size:12px; line-height:1.5; background: var(--ds-card, #1b1f27); border:1px solid var(--ds-line); box-shadow:0 4px 14px rgba(0,0,0,.35); font-variant-numeric: tabular-nums; white-space:nowrap; } .enpanel .en-tip[hidden] { display:none; } .enpanel .en-tip b { display:block; font-weight:600; margin-bottom:2px; } .enpanel .en-tip i { display:inline-block; width:8px; height:8px; border-radius:50%; margin-right:6px; }
.enpanel svg.en-ch { cursor:crosshair; touch-action:pan-y; user-select:none; -webkit-user-select:none;} .enpanel svg.en-ch { display:block; width:100%; height:auto; overflow:visible; } .enpanel svg text { font-size:11px; fill: var(--ds-fg2); }
.enpanel .en-tb { display:grid; grid-template-columns: 1.1fr .7fr 1fr 1fr; gap:6px; font-size:13px; padding:8px 2px; border-top:1px solid var(--ds-line); font-variant-numeric: tabular-nums; }
.enpanel .en-tb.f4 { grid-template-columns: 1fr .65fr 1fr 1fr .85fr; } .enpanel .en-tb .fu { color: #f3bd62; }
.enpanel .en-tb .bu { color:rgb(var(--ds-info)); } .enpanel .en-tb > span { min-width:0; overflow-wrap:anywhere; }
.enpanel .en-infotog { width:100%; display:flex; align-items:center; gap:8px; min-height:44px; margin-top:10px; padding:10px 12px; border-radius:14px; border:1px solid var(--ds-line); background: var(--ds-soft); color: var(--ds-fg); font:inherit; font-size:13px; font-weight:600; cursor:pointer; } .enpanel .en-infotog span { flex:1; text-align:left; } .enpanel .en-infotog .i { --is:20px; flex:none; } .enpanel .en-info[hidden] { display:none; }
.enpanel .en-info { display:flex; align-items:flex-start; gap:8px; padding:10px 12px; border:1px solid var(--ds-line); border-radius:12px; background:rgba(128,128,128,.05); color:var(--ds-fg2); font-size:11px; line-height:1.45; } .enpanel .en-info p { margin:0; font:inherit; } .enpanel .en-info p + p { margin-top:3px; } .enpanel .en-info-icon { flex:none; font-size:14px; line-height:1.3; }
.enpanel .en-tb.h { border-top:0; padding:0 2px 4px; font-size:11.5px; color: var(--ds-fg2); } .enpanel .en-tb > :not(:first-child) { text-align:right; } .enpanel .en-tb .z { color: var(--ds-fg2); } .enpanel .en-tb .ok { color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); }
.enpanel .en-li { display:flex; justify-content:space-between; align-items:center; gap:12px; padding:12px 2px; border-top:1px solid var(--ds-line); font-size:13.5px; }
.enpanel .en-li .a { display:flex; gap:12px; min-width:0; flex:1; align-items:center; } .enpanel .en-li .ic { flex:none; width:34px; height:34px; border-radius:50%; background: rgba(var(--ds-ac,var(--ds-ok,52,211,153)), .14); color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); display:flex; align-items:center; justify-content:center; } .enpanel .en-li .ic .i { --is:18px; }
.enpanel .en-li .mid { flex:1; min-width:0; } .enpanel .en-li .bd { font-size:10px; font-weight:600; padding:1px 7px; border-radius:8px; margin-left:6px; background: rgba(var(--ds-ac,var(--ds-ok,52,211,153)), .14); color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); vertical-align:1px; }
.enpanel .en-li .bar { position:relative; height:6px; border-radius:3px; background: var(--ds-line); margin:7px 0 4px; overflow:hidden; } .enpanel .en-li .bar i { position:absolute; top:0; bottom:0; border-radius:3px; background: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); }
.enpanel .en-li .b { text-align:right; font-size:16px; font-weight:600; color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); font-variant-numeric: tabular-nums; white-space:nowrap; }
.enpanel .en-li small { display:block; color: var(--ds-fg2); font-size:12px; font-variant-numeric: tabular-nums; }
.enpanel .en-tot { display:grid; grid-template-columns: repeat(3, minmax(0,1fr)); gap:8px; } .enpanel .en-tot div { border-radius:12px; padding:9px 12px; background: rgba(var(--rgb-primary-text-color, 255,255,255), .04); border:1px solid var(--ds-line); font-size:12px; color: var(--ds-fg2); } .enpanel .en-tot b { display:block; margin-top:2px; font-size:18px; font-weight:600; color: var(--ds-fg); font-variant-numeric: tabular-nums; } .enpanel .en-tot b.ok { color: rgb(var(--ds-ac,var(--ds-ok,52,211,153))); }
.enpanel .en-empty { display:flex; flex-direction:column; align-items:center; gap:10px; padding:30px 18px; text-align:center; color: var(--ds-fg2); font-size:13.5px; line-height:1.5; }
`;
const CL_OK = "var(--energy-charge)", CL_DRV = "var(--energy-drive)", CL_FUEL = "var(--energy-fuel)";
const ENT = { batt: "sensor.battery_level", ac: "sensor.ac_charge_current", dc: "sensor.dc_charge_current", odo: "sensor.total_odometer", pow: "sensor.power_status", fuel: "sensor.fuel_level", range: "sensor.remaining_range", left: "sensor.remaining_charge_time_h_mm", volume: "sensor.fuel_volume" };

/* Smooth curve (monotone cubic: no overshoot) from points [x,y] with increasing x */
function mono(P) {
  const n = P.length; if (n < 2) return ""; const dx = [], m = [];
  for (let i = 0; i < n - 1; i++) { dx[i] = P[i + 1][0] - P[i][0]; m[i] = (P[i + 1][1] - P[i][1]) / dx[i]; }
  const t = [m[0]]; for (let i = 1; i < n - 1; i++) t[i] = m[i - 1] * m[i] <= 0 ? 0 : (3 * (dx[i - 1] + dx[i])) / ((2 * dx[i] + dx[i - 1]) / m[i - 1] + (dx[i] + 2 * dx[i - 1]) / m[i]); t[n - 1] = m[n - 2];
  for (let i = 0; i < n - 1; i++) { if (m[i] === 0) { t[i] = t[i + 1] = 0; continue; } const a = t[i] / m[i], b = t[i + 1] / m[i], q = a * a + b * b; if (q > 9) { const k = 3 / Math.sqrt(q); t[i] = k * a * m[i]; t[i + 1] = k * b * m[i]; } }
  let d = `M${P[0][0].toFixed(1)} ${P[0][1].toFixed(1)}`;
  for (let i = 0; i < n - 1; i++) { const h = dx[i] / 3; d += ` C${(P[i][0] + h).toFixed(1)} ${(P[i][1] + t[i] * h).toFixed(1)} ${(P[i + 1][0] - h).toFixed(1)} ${(P[i + 1][1] - t[i + 1] * h).toFixed(1)} ${P[i + 1][0].toFixed(1)} ${P[i + 1][1].toFixed(1)}`; }
  return d;
}
/* Values are recorded only on changes: we hold the value and change it gradually (up to RAMP before the next change) so the curve is smooth and not stepped */
const RAMP = 60 * 60e3;
function ramped(ser, t0, now) {
  const first = at(ser, t0); if (!Number.isFinite(first)) return [];
  const out = [[t0, first]];
  for (const p of ser) { if (p[0] <= t0 || p[0] > now) continue; const l = out[out.length - 1]; if (p[0] - l[0] > RAMP) out.push([p[0] - RAMP, l[1]]); out.push([p[0], p[1]]); }
  out.push([now, out[out.length - 1][1]]); return out;
}

/* Charging costs: per-account profiles and explicit per-session attribution. */
const cn = v => v === "" || v == null || !Number.isFinite(Number(v)) || Number(v) < 0 ? null : Number(v);
const profileName = p => p.name || ({home:T("Home"),work:T("Work"),public:T("Public"),free:T("Free"),ionity:"Ionity",manual:T("Manual charge")}[p.id] || p.id);
const defaultProfiles = () => ["home","work","free","ionity","public"].map(id=>({id,name:"",price:null,free:id==="work"||id==="free",source:"battery",entity:"",efficiency:90}));
function chargingEnergy(g, r, series = [], unit = "") {
  if (!r) return {energy:null,source:"unassigned",estimated:true};
  if (cn(r.energy)!==null) return {energy:cn(r.energy),source:"receipt",estimated:false};
  const p=r.profile, power=p.source==="power", factor=power?(unit==="W"?.001:unit==="kW"?1:null):(unit==="Wh"?.001:unit==="kWh"?1:null);
  if (p.source!=="battery" && factor!==null && series.length) {
    const rows=series.filter(x=>Number.isFinite(x[1])&&x[1]>=0&&x[0]<=g.e), before=rows.filter(x=>x[0]<=g.s).slice(-1)[0];
    if(before && g.s-before[0]<=20*60e3) {
      let last=before, value=0, valid=true;
      for(const row of rows.filter(x=>x[0]>g.s)) {
        if(row[0]-last[0]>20*60e3) {valid=false;break;}
        if(power) value+=last[1]*(row[0]-Math.max(g.s,last[0]))/36e5;
        else if(row[1]>=last[1]) value+=row[1]-last[1];
        else {valid=false;break;}
        last=row;
      }
      if(g.e-last[0]>20*60e3)valid=false;
      if(power&&valid)value+=last[1]*(g.e-Math.max(g.s,last[0]))/36e5;
      if(valid&&Number.isFinite(value*factor)&&value*factor>0&&value*factor<=1000000)return {energy:value*factor,source:power?"power":"meter",estimated:power};
    }
  }
  const efficiency=Number(p.efficiency),stored=r.capacity>0&&Number.isFinite(g.to)&&Number.isFinite(g.from)?Math.max(0,g.to-g.from)*r.capacity/100:g.kwh;
  const energy=stored>0&&efficiency>0&&efficiency<=100?stored/(efficiency/100):null;
  return {energy,source:p.source==="battery"?"battery":"fallback",estimated:true};
}
function chargingCost(g,r,series,unit) {
  const e=chargingEnergy(g,r,series,unit);if(!r)return {...e,cost:null};
  const total=cn(r.total),price=cn(r.profile.price);
  const cost=total!==null?total:r.profile.free?0:price!==null&&e.energy!==null?price*e.energy:null;
  return {...e,costEstimated:total===null&&!r.profile.free&&e.estimated,cost:cost===null||Number.isFinite(cost)?cost:null};
}
EN.costMath={chargingEnergy,chargingCost};
function energyDayStart(offset, timezone, now=Date.now()) {
  if(!timezone)return NaN;
  const fields=(stamp,withTime=false)=>Object.fromEntries(new Intl.DateTimeFormat('en-CA',{timeZone:timezone,...(withTime?{hourCycle:'h23',hour:'2-digit',minute:'2-digit',second:'2-digit'}:{}),year:'numeric',month:'2-digit',day:'2-digit'}).formatToParts(new Date(stamp)).map(part=>[part.type,part.value]));
  const today=fields(now),date=new Date(Date.UTC(+today.year,+today.month-1,+today.day+offset)),target=Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate());
  let guess=target;for(let i=0;i<3;i++){const local=fields(guess,true);guess+=target-Date.UTC(+local.year,+local.month-1,+local.day,+local.hour,+local.minute,+local.second);}
  return guess;
}
EN.periodDayStart=energyDayStart;
class ChargingCosts {
  constructor(card,host) {
    this.card=card;this.host=host;this.data={profiles:defaultProfiles(),sessions:{}};this.queue=Promise.resolve();this.editor=null;this.message="";this.dirty=false;
    this.key="deepal_charge_costs_"+(card._c?.prefix||"s05");this.cacheKey=this.key+"_"+(card._hass?.user?.id||"local")+"_"+(card._companion?.vehicle_id||"");this.ready=this.load();
    host.addEventListener("click",e=>this.click(e));
    host.addEventListener('pointerdown',e=>{
      const grip=e.target.closest?.('.cc-grip');if(!grip||this.saving||(e.pointerType==='mouse'&&e.button!==0))return;
      clearTimeout(this.autoTimer);
      const row=grip.closest('.cc-location-details');
      window.__DEEPAL_COMPANION_UI.startReorder(e,grip,row,row.parentElement,(from,to)=>{
        this.data.profiles=this.collectProfiles(false);const [profile]=this.data.profiles.splice(from,1);this.data.profiles.splice(to,0,profile);this.renderEditor();
      },()=>this.scheduleProfileSave());
    });
    host.addEventListener("input",e=>{if(e.target.name==="total")this.manualTotal(e.target.closest("form"));if(e.target.closest("[data-cc-form]"))this.updateDirty();if(e.target.closest('[data-cc-form="profiles"]'))this.scheduleProfileSave(2000);});
    host.addEventListener("change",e=>{

      if(e.target.name==="total")this.manualTotal(e.target.closest("form"));
      if(e.target.matches("[data-cc-source]")){const group=e.target.closest(".cc-profile");group.querySelector("[data-cc-entity-field]").hidden=e.target.value==="battery";this.bindEntityPicker(group);}
      if(e.target.matches("[name=free]")&&e.target.closest(".cc-profile")){e.target.closest(".cc-profile").querySelector(".cc-paid").hidden=e.target.checked;}
      if(e.target.matches(".cc-profile [name=default]")&&e.target.checked)e.target.closest("[data-cc-form]").querySelectorAll(".cc-profile [name=default]").forEach(box=>{if(box!==e.target)box.checked=false;}); /* only one profile is suggested */
      if(e.target.matches("[name=profile]"))this.selectLocation(e.target.closest("form"));
      const group=e.target.closest('.cc-profile'),summary=group?.parentElement.querySelector('summary');
      if(summary){group.parentElement.classList.toggle('is-free',group.querySelector('[name=free]').checked);summary.querySelector('span').textContent=group.querySelector('[name=name]').value;summary.querySelector('small').textContent=group.querySelector('[name=free]').checked?T("Free charging"):group.querySelector('[name=price]').value?group.querySelector('[name=price]').value+' €/kWh':T("Set price");}
      if(e.target.closest("[data-cc-form]"))this.updateDirty();
      if(e.target.closest('[data-cc-form="profiles"]'))this.scheduleProfileSave();
    });
  }
  async flush(){if(this.autoTimer)await this.autoSaveProfiles();for(let i=0;i<60&&this.saving;i++)await new Promise(r=>setTimeout(r,50));}
  scheduleProfileSave(delay=350){clearTimeout(this.autoTimer);this.autoTimer=setTimeout(()=>this.autoSaveProfiles(),delay);}
  captureUi(){const root=this.editorNode?.getRootNode(),a=root?.activeElement,g=a?.closest?.('.cc-profile');return {open:[...this.editorNode.querySelectorAll('.cc-location-details')].map(d=>d.open),focus:g&&a.name?{i:g.dataset.index,n:a.name,s:a.selectionStart,e:a.selectionEnd}:null};}
  restoreUi(u){if(!u||!this.editorNode?.isConnected)return;[...this.editorNode.querySelectorAll('.cc-location-details')].forEach((d,i)=>{d.open=!!u.open[i];});if(u.focus){const el=this.editorNode.querySelector('.cc-profile[data-index="'+u.focus.i+'"] [name="'+u.focus.n+'"]');if(el){el.focus({preventScroll:true});try{if(u.focus.s!=null)el.setSelectionRange(u.focus.s,u.focus.e);}catch(_){}}}}
  async autoSaveProfiles(){
    clearTimeout(this.autoTimer);
    if(this.saving||this.editor!=='profiles'||!this.editorNode?.querySelector('form'))return;
    const status=this.editorNode.querySelector('[role="status"]'),show=text=>{this.message=text;if(status){status.hidden=false;status.textContent=text;}};
    let profiles;try{profiles=this.collectProfiles();}catch(error){show(tError(error.message));return;}
    if(!this.editorNode.querySelector('form').reportValidity())return;
    if(JSON.stringify(profiles)===JSON.stringify(this.data.profiles)&&JSON.stringify(this.data)===this.savedData)return;
    this.data.profiles=profiles;this.saving=true;const before=this.formState(),ui=this.captureUi();
    try{await this.save();this.formBaseline=before;this.updateDirty();
      if(this.formState()===before){await this.history(this.model);this.decorate(this.model,this.ctx);this.restoreUi(ui);const note=this.editorNode?.querySelector('[role="status"]');if(note){note.hidden=false;note.textContent=T("Saved automatically.");}this.message=T("Saved automatically.");}
      else this.scheduleProfileSave();}
    catch(error){show(tError(error.message));}
    finally{this.saving=false;}
  }
  formState(){const form=this.editorNode?.querySelector("form");return form?JSON.stringify([...form.querySelectorAll("input,select,textarea")].map(n=>[n.name,n.type==="checkbox"?n.checked:n.value])):null;}
  updateDirty(){const form=this.formState();this.dirty=JSON.stringify(this.data)!==this.savedData||(form!==null&&form!==this.formBaseline);this.onDirtyChange?.(this.dirty);}
  async load() {
    try{const local=JSON.parse(localStorage.getItem(this.cacheKey)||"null");if(Array.isArray(local?.profiles)&&local.sessions)this.data=local;}catch(_){}
    try{const r=await this.card._hass.callWS({type:"frontend/get_user_data",key:this.key});if(Array.isArray(r?.value?.profiles)&&r.value.sessions)this.data=r.value;this.cloudLoaded=true;}
    catch(_){this.message=T("Account unavailable; local copy loaded.");}
    this.savedData=JSON.stringify(this.data);
  }
  async save() {
    const snapshot=JSON.parse(JSON.stringify(this.data));try{localStorage.setItem(this.cacheKey,JSON.stringify(snapshot));}catch(_){}
    const send=this.queue.catch(()=>{}).then(async()=>{
      if(!this.cloudLoaded){
        const remote=await this.card._hass.callWS({type:"frontend/get_user_data",key:this.key});
        snapshot.sessions={...(remote?.value?.sessions||{}),...snapshot.sessions};this.data.sessions={...snapshot.sessions};this.cloudLoaded=true;
      }
      return this.card._hass.callWS({type:"frontend/set_user_data",key:this.key,value:snapshot});
    });this.queue=send;
    try{await send;this.savedData=JSON.stringify(snapshot);this.onSaved?.();this.message=T("Saved to your HA account.");return true;}
    catch(error){throw Error(T("Saved on this device only. Account save failed.")+" "+tError(error.message||String(error)));}
  }
  record(g){return g?this.data.sessions[String(Math.round(g.s/1000))]:undefined;}
  profileRemoved(profile){return !!profile?.id&&profile.id!=='manual'&&!this.data.profiles.some(p=>p.id===profile.id);}
  async history(m) {
    if(this.card._hass.companionRequest){const records=this.archiveOnly?(await EN.loadChargingSessions(this.card)).rows:await this.card._hass.companionRequest("sessions",{start_time:new Date(m.t0).toISOString(),end_time:new Date(m.now).toISOString()});for(const g of m.chg){const row=records.find(r=>r.s===g.s);if(row){g.pricing=row.pricing;g.assignment=row.assignment;}}}
    if(this.archiveOnly)return;
    this.sensorHistory={};
    const entities=[...new Set([...this.data.profiles,...Object.values(this.data.sessions).map(r=>r.profile)].filter(p=>p&&p.source!=="battery"&&p.entity).map(p=>p.entity))];
    if(!entities.length)return;
    try{const raw=await this.card._hass.callWS({type:"history/history_during_period",start_time:new Date(m.t0-20*60e3).toISOString(),end_time:new Date(m.now).toISOString(),entity_ids:entities,include_start_time_state:true,significant_changes_only:false,minimal_response:true,no_attributes:true});for(const id of entities)this.sensorHistory[id]=numSeries(rowsOf(raw?.[id]));}catch(_){}
  }
  result(g){const r=this.record(g);if(g.pricing&&JSON.stringify(g.assignment||null)===JSON.stringify(r||null))return {...g.pricing,costEstimated:g.pricing.cost_estimated};const id=r?.profile?.entity;return chargingCost(g,r,this.sensorHistory?.[id]||[],this.card._hass.states?.[id]?.attributes?.unit_of_measurement||"");}
  money(v){const lang=this.card._hass?.locale?.language||"en",currency=this.card._hass?.config?.currency||"EUR";try{return new Intl.NumberFormat(lang,{style:"currency",currency}).format(v);}catch(_){return new Intl.NumberFormat(lang,{style:"currency",currency:"EUR"}).format(v);}}
  number(v){return new Intl.NumberFormat(this.card._hass?.locale?.language||"en",{maximumFractionDigits:2}).format(v);}
  label(r){return {unassigned:T("Choose location"),receipt:T("Entered energy"),meter:T("Measured energy"),power:T("Estimated from power"),battery:T("Estimated from battery"),fallback:T("Sensor unavailable, using battery estimate")}[r.source];}
  decorate(m,ctx) {
    this.model=m;this.ctx=ctx;const b=this.host.querySelector(".en-body");if(!b)return;
    const graph=b.querySelector(".cc-charts");if(graph&&EN.renderChargingChart)graph.outerHTML=EN.renderChargingChart(m.chg,this.card._hass.locale?.language||"en",m.now,{fmt:ctx.fmt});
    b.querySelectorAll(".cc-added").forEach(n=>n.remove());
    const completed=m.chg.filter(g=>!g.live),results=completed.map(g=>this.result(g)),known=results.filter(r=>r.cost!==null),total=known.reduce((n,r)=>n+r.cost,0);
    const canEdit=this.card._hass?.user?.is_admin!==false;/* the backend only lets administrators save costs */
    const top=document.createElement("div");top.className="cc-added cc-summary";
    top.innerHTML='<div><small>'+esc(T("Charging cost"))+'</small><b>'+(known.length?(known.every(r=>r.cost===0)?esc(T("Free charging")):esc(this.money(total))):"—")+'</b><small>'+known.length+"/"+completed.length+" "+esc(T("sessions priced"))+(known.some(r=>r.costEstimated)?" · ≈":"")+'</small></div>'+(canEdit?'<button class="cc-button" data-cc="profiles">'+esc(T("Charging profiles"))+' ⚙</button>':'');
    const totals=b.querySelector(".en-tot");if(totals)totals.after(top);else b.prepend(top);
    const days=m.days.filter(d=>d.t<=m.now).slice().reverse();
    [...b.querySelectorAll(".en-tb:not(.h)")].forEach((row,i)=>{
      const day=days[i];if(!day)return;const values=m.chg.filter(g=>dayKey(g.s,m.timezone)===day.key).map(g=>this.result(g));if(!values.length)return;
      const priced=values.filter(r=>r.cost!==null),sum=priced.reduce((n,r)=>n+r.cost,0),note=document.createElement("small");note.className="cc-added cc-day-cost";
      note.textContent=priced.length?priced.every(r=>r.cost===0)?T("Free")+(priced.length<values.length?" *":""):(priced.some(r=>r.costEstimated)?"≈ ":"")+this.money(sum)+(priced.length<values.length?" *":""):T("Price not set");
      note.title=T("Charging cost. * = some sessions have no price.");row.children[2]?.append(note);
    });
    const list=m.chg.slice().reverse();
    [...b.querySelectorAll(".en-li")].forEach((row,i)=>{
      const g=list[i];if(!g)return;const r=this.record(g),result=this.result(g),n=document.createElement("button");
      n.className="cc-added cc-session";if(canEdit)n.dataset.cc="session";else n.setAttribute("aria-disabled","true");n.dataset.start=String(g.s);
      n.dataset.costState=result.cost===null?'unpriced':result.cost===0?'free':'paid';
      n.innerHTML='<span><span class="cc-location-name">'+esc(r?profileName(r.profile):T("Choose location"))+'</span><small>'+esc(this.label(result))+(result.energy!==null?" · "+esc(this.number(result.energy))+" kWh":"")+'</small></span><span class="cc-price-badge"><span><small>'+esc(result.cost===0?T("Free charging"):result.cost!==null?T("Cost"):T("Not priced"))+'</small><b>'+(result.cost!==null?(result.estimated&&cn(r?.total)===null&&!r?.profile.free?"≈ ":"")+esc(this.money(result.cost)):esc(T("Set price")))+'</b></span><i aria-hidden="true">›</i></span>';if(!canEdit)n.querySelector('.cc-price-badge i')?.remove();const group=document.createElement('div');group.className='cc-added cc-session-row';n.classList.remove('cc-added');group.append(n);
      if(this.profileRemoved(r?.profile)){const warning=document.createElement('span');warning.className='cc-removed-profile';warning.innerHTML='<ha-icon icon="mdi:map-marker-alert-outline"></ha-icon> '+esc(T("Profile removed · assign another"));n.querySelector('.cc-location-name').append(warning);}
      const curve=document.createElement('button');curve.className='cc-button cc-curve';curve.dataset.cc='curve';curve.dataset.start=String(g.s);curve.innerHTML=ico('pulse');curve.setAttribute('aria-label',T('View charging curve'));curve.title=T('View charging curve');group.append(curve);row.after(group);
    });
    const editor=document.createElement("div");editor.className="cc-added cc-editor";const anchor=this.editor&&this.editor!=="profiles"?[...b.querySelectorAll(".cc-session")].find(n=>n.dataset.start===String(this.editor)):null;(anchor?.closest('.cc-session-row')||anchor||top).after(editor);this.editorNode=editor;this.renderEditor();EN.bindChargingChart?.(b,ctx.fmt);
  }
  field(label,name,value,type="text",extra=""){return '<label class="cc-field">'+esc(label)+'<input name="'+esc(name)+'" type="'+type+'" value="'+esc(name==="efficiency"&&Number(value)===90?"":value??"")+'"'+(name==="efficiency"?' placeholder="90"':"")+' '+(type==="number"?'min="0" step="any" ':"")+extra+"></label>";}
  bindEntityPicker(group){
    const holder=group.querySelector('.cc-entity-picker');if(!holder)return;
    const hidden=group.querySelector('[name=entity]'),source=group.querySelector('[name=source]').value,units=source==='power'?['W','kW']:['Wh','kWh'];
    const hass=this.card._hass,ids=Object.keys(hass.states||{}).filter(id=>id.startsWith('sensor.')&&units.includes(hass.states[id].attributes?.unit_of_measurement));
    const friendly=id=>hass.states?.[id]?.attributes?.friendly_name||hass.entities?.[id]?.name||id;
    ids.sort((a,b)=>friendly(a).localeCompare(friendly(b)));
    holder.replaceChildren();const note=group.querySelector('.cc-entity-name');
    const update=value=>{hidden.value=value;note.textContent=value?(friendly(value)+' · '+value):'';this.updateDirty();this.scheduleProfileSave();};
    note.textContent=hidden.value?(friendly(hidden.value)+' · '+hidden.value):'';
    if(customElements.get('ha-selector')){
      const picker=document.createElement('ha-selector');picker.dataset.chargerEntity='';picker.hass=hass;picker.label=T("Charger sensor");picker.required=false;
      picker.selector={entity:{domain:'sensor',include_entities:ids}};picker.value=hidden.value||undefined;
      picker.addEventListener('value-changed',event=>{event.stopPropagation();update(typeof event.detail?.value==='string'?event.detail.value:'');});holder.append(picker);
    }else{
      const picker=document.createElement('select');picker.setAttribute('aria-label','Charger sensor');
      picker.innerHTML='<option value="">'+esc(T("Choose a sensor"))+'</option>'+ids.map(id=>'<option value="'+esc(id)+'">'+esc(friendly(id)+' · '+id)+'</option>').join('');
      if(hidden.value&&!ids.includes(hidden.value))picker.add(new Option(friendly(hidden.value)+' · '+hidden.value,hidden.value));
      picker.value=hidden.value;picker.addEventListener('change',()=>update(picker.value));holder.append(picker);
    }
  }
  cancelChanges(){
    if(this.saving)return;
    if(this.savedData){this.data=JSON.parse(this.savedData);try{localStorage.setItem(this.cacheKey,this.savedData);}catch(_){}}
    this.message='';this.dirty=false;
    if(this.editor==='profiles')this.renderEditor();else{this.editor=null;this.editorNode.replaceChildren();}
    this.onDirtyChange?.(false);this.onCanceled?.();
  }
  options(value){return [["battery",T("Battery estimate")],["total",T("Total energy meter")],["session",T("Session energy meter")],["power",T("Charger power")]].map(([v,l])=>'<option value="'+v+'"'+(v===value?" selected":"")+">"+esc(l)+"</option>").join("");}
  renderEditor() {
    if(!this.editorNode)return;if(!this.editor){this.editorNode.innerHTML="";return;}
    const close='<button class="cc-button cc-close" data-cc="close" aria-label="'+esc(T("Close"))+'" title="'+esc(T("Close"))+'">'+ico("close")+'</button>',message=this.message?'<p class="cc-info" role="status">ⓘ '+esc(this.message)+"</p>":'<p class="cc-info" role="status" hidden></p>';
    if(this.editor==="profiles"){
      const sensorOptions=Object.entries(this.card._hass.states||{}).filter(([id,s])=>id.startsWith("sensor.")&&["Wh","kWh","W","kW"].includes(s.attributes?.unit_of_measurement)).map(([id,s])=>'<option value="'+esc(id)+'">'+esc(s.attributes?.friendly_name||id)+"</option>").join("");
      const usage={};for(const r of Object.values(this.data.sessions||{})){const id=r?.profile?.id;if(id==null)continue;const u=usage[id]||(usage[id]={n:0,kwh:0});u.n++;u.kwh+=Number(r.energy)||0;}
      const profiles=this.data.profiles.map((p,i)=>{const u=usage[p.id]||{n:0,kwh:0};return '<details class="cc-location-details'+(p.free?' is-free':'')+'"><summary><i class="cc-loc-ic" aria-hidden="true">'+ico(p.free?'leaf':'bolt')+'</i><span class="cc-loc-t"><b>'+esc(profileName(p))+'</b><em>'+esc(!u.n?T("No charges yet"):(u.n===1?T("1 charge"):T("{0} charges",u.n))+(u.kwh>0?" · "+new Intl.NumberFormat(this.ctx?.lang,{maximumFractionDigits:1}).format(u.kwh)+" kWh":""))+'</em></span><small class="cc-loc-p'+(p.free?' free':p.price==null?' unset':'')+'">'+esc(p.free?T("Free charging"):p.price!=null?p.price+' €/kWh':T("Set price"))+'</small><span aria-hidden="true">›</span></summary><fieldset class="cc-profile" data-index="'+i+'"><legend>'+esc(profileName(p))+'</legend><div class="cc-profile-head">'+this.field(T("Name"),"name",p.name||profileName(p))+'<label class="cc-check"><input name="free" type="checkbox"'+(p.free?' checked':'')+'>'+esc(T("Free charging"))+'</label><label class="cc-check"><input name="default" type="checkbox"'+(p.default?' checked':'')+'>'+esc(T("Suggest for new charges"))+'</label></div><div class="cc-paid"'+(p.free?' hidden':'')+'><div class="cc-grid">'+this.field("€/kWh","price",p.price,"number")+'<label class="cc-field">'+esc(T("Energy source"))+'<select name="source" data-cc-source>'+this.options(p.source)+'</select></label><div data-cc-entity-field'+(p.source==="battery"?' hidden':'')+'>'+'<input type="hidden" name="entity" value="'+esc(p.entity||'')+'"><div class="cc-entity-picker"></div><small class="cc-entity-name"></small>'+'</div></div></div><div class="cc-grid">'+this.field(T("Battery estimate efficiency (%)"),"efficiency",p.efficiency,"number",'min="1" max="100"')+'</div><p class="cc-hint">'+esc(T("Efficiency applies only to battery-based estimates. Charger and receipt energy are used as measured."))+'</p><button type="button" class="cc-button danger" data-cc="remove-profile">'+esc(T("Delete charging profile"))+'</button></fieldset></details>';}).join("");
      this.editorNode.innerHTML='<form data-cc-form="profiles"><div class="cc-editor-head"><b>'+esc(T("Charging profiles"))+'</b>'+close+'</div><p class="cc-hint">'+esc(T("Each location has its own tariff and optional charger sensor. Saved sessions keep their price."))+'</p><datalist id="cc-sensors">'+sensorOptions+'</datalist><div class="cc-profiles">'+profiles+'</div><div class="cc-actions"><button class="cc-button" data-cc="add">'+esc(T("Add location"))+'</button></div>'+message+'</form>';
    } else {
      const g=this.model.chg.find(g=>String(g.s)===String(this.editor));if(!g){this.editor=null;return;}const r=this.record(g),p=r?.profile,result=this.result(g);
      const locations=this.data.profiles.map(x=>{
        const rate=x.free?T("Free"):cn(x.price)!==null?this.number(x.price)+" €/kWh":T("Price not set");
        return '<option value="'+esc(x.id)+'"'+(x.id===p?.id?" selected":"")+">"+esc(profileName(x)+" · "+rate)+"</option>";
      }).join("")+'<option value="__manual__"'+(p?.id==="manual"?" selected":"")+'>'+esc(T("Manual charge (no profile)"))+"</option>";
      const advanced=this.field("€/kWh","price",p?.price,"number")+'<label class="cc-check"><input name="free" type="checkbox"'+(p?.free?" checked":"")+">"+esc(T("Free charging"))+"</label>"+this.field(T("Receipt energy (kWh), optional"),"energy",r?.energy,"number")+this.field(T("Total paid (€), optional"),"total",r?.total,"number");
      this.editorNode.innerHTML='<form data-cc-form="session"><div class="cc-editor-head"><b>'+esc(T("Charging location"))+" · "+esc(this.ctx.fmt.hm(g.s))+"</b>"+close+'</div><label class="cc-field cc-location">'+esc(T("Location"))+'<select name="profile"><option value="">'+esc(T("Choose location"))+"</option>"+locations+'</select></label><p class="cc-hint">'+esc(T("The saved location profile supplies the price or free charging."))+'</p><details class="cc-advanced"'+(p?.id==="manual"?" open":"")+'><summary>'+esc(T("Receipt or manual correction"))+'</summary><div class="cc-grid">'+advanced+'</div><p class="cc-hint">'+esc(T("Enter €/kWh and kWh, or only the total paid. The total wins if both are entered."))+'</p></details><div class="cc-actions"><button class="cc-button" data-cc="cancel">'+esc(T("Cancel changes"))+'</button><button class="cc-button primary" data-cc="save-session">'+esc(T("Save location"))+"</button></div>"+message+"</form>";
    }
    if(this.editor!=='profiles'&&this.profileRemoved(this.record(this.model.chg.find(g=>String(g.s)===String(this.editor)))?.profile)){const notice=document.createElement('p');notice.className='cc-info cc-removed-profile';notice.setAttribute('role','note');notice.textContent=T("This profile was removed. Location and cost are kept. Pick another profile to reassign it.");this.editorNode.querySelector('.cc-location').after(notice);}
    this.editorNode.querySelectorAll('.cc-location-details').forEach(details=>details.addEventListener('toggle',()=>{
      if(details.open)this.editorNode.querySelectorAll('.cc-location-details').forEach(other=>{if(other!==details)other.open=false;});
    }));
    this.editorNode.querySelector("form")?.addEventListener("submit",e=>e.preventDefault());
    this.editorNode.querySelectorAll(".cc-profile").forEach(group=>this.bindEntityPicker(group));
    window.__DEEPAL_COMPANION_UI?.enhanceChoices(this.editorNode,this.card._hass);
    this.bindProfileNames();
    this.editorNode.querySelectorAll('.cc-location-details>summary').forEach(summary=>{
      const grip=document.createElement('button');grip.type='button';grip.className='cc-grip';grip.textContent='⠿';grip.setAttribute('aria-label',T('Reorder'));grip.style.cssText='touch-action:none;cursor:grab;padding:6px;border:0;background:transparent;color:inherit;flex:none';grip.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();});
      grip.addEventListener('keydown',e=>{if(!['ArrowUp','ArrowDown'].includes(e.key)||this.saving)return;e.preventDefault();const row=summary.parentElement,rows=[...row.parentElement.children],from=rows.indexOf(row),to=from+(e.key==='ArrowUp'?-1:1);if(to<0||to>=rows.length)return;this.data.profiles=this.collectProfiles(false);const [profile]=this.data.profiles.splice(from,1);this.data.profiles.splice(to,0,profile);this.renderEditor();this.editorNode.querySelectorAll('.cc-grip')[to]?.focus();this.scheduleProfileSave();});summary.prepend(grip);
    });
    this.formBaseline=this.formState();this.updateDirty();
  }
  manualTotal(form){
    if(!form?.elements.total||cn(form.elements.total.value)===null)return;
    const profile=form.elements.profile;if(profile.value!=='__manual__')form.elements.price.value='';
    profile.value='__manual__';if(profile._compPicker)profile._compPicker.value='__manual__';form.elements.free.checked=false;
    form.querySelector('.cc-advanced').open=true;
  }
  bindProfileNames(){
    const names=[['IONITY','Europe'],['Tesla Supercharger','Europe'],['Atlante','Spain · Italy'],['Zunder','Spain'],['Iberdrola | bp pulse','Spain'],['Repsol','Spain'],['Wenea','Spain'],['Plenitude On the Road','Italy','Be Charge'],['Ewiva','Italy'],['Free To X','Italy'],['A2A E-moving','Italy'],['PPC blue','Greece',T("PPC blue (Greek name)")],['incharge','Greece','nrg'],['EKO Charge & Go','Greece','ElpeFuture'],['Blink Charging','Greece'],['EV Loader','Greece'],['Electrip','Greece']];
    for(const input of this.editorNode.querySelectorAll('.cc-profile input[name=name]')){
      const field=input.closest('label');field.classList.add('cc-name-field');input.autocomplete='off';input.setAttribute('role','combobox');input.setAttribute('aria-autocomplete','list');input.setAttribute('aria-expanded','false');
      const list=document.createElement('div');list.className='cc-name-options';list.hidden=true;list.setAttribute('role','listbox');list.id='cc-network-'+input.closest('.cc-profile').dataset.index;input.setAttribute('aria-controls',list.id);field.append(list);let active=-1;
      const close=()=>{list.hidden=true;active=-1;input.setAttribute('aria-expanded','false');input.removeAttribute('aria-activedescendant');};
      const choose=name=>{input.value=name;close();input.dispatchEvent(new Event('input',{bubbles:true}));input.dispatchEvent(new Event('change',{bubbles:true}));close();};
      const show=()=>{const q=input.value.trim().toLocaleLowerCase();const matches=names.filter(n=>n.join(' ').toLocaleLowerCase().includes(q)).slice(0,6);list.replaceChildren();active=-1;for(const [i,item]of matches.entries()){const option=document.createElement('button');option.type='button';option.id=list.id+'-'+i;option.setAttribute('role','option');option.setAttribute('aria-selected','false');option.textContent=item[0]+' · '+item[1];option.addEventListener('pointerdown',e=>e.preventDefault());option.addEventListener('click',()=>choose(item[0]));list.append(option);}list.hidden=!matches.length;input.setAttribute('aria-expanded',String(!!matches.length));input.removeAttribute('aria-activedescendant');};
      input.addEventListener('focus',show);input.addEventListener('input',show);input.addEventListener('blur',close);
      input.addEventListener('keydown',e=>{if(e.key==='Escape'){close();return;}if(e.key==='Enter'&&!list.hidden&&active>=0){e.preventDefault();choose(list.children[active].textContent.split(' · ')[0]);return;}if(!['ArrowDown','ArrowUp'].includes(e.key))return;e.preventDefault();if(list.hidden)show();const count=list.children.length;if(!count)return;active=(active+(e.key==='ArrowDown'?1:-1)+count)%count;[...list.children].forEach((n,i)=>n.setAttribute('aria-selected',String(i===active)));input.setAttribute('aria-activedescendant',list.children[active].id);list.children[active].scrollIntoView({block:'nearest'});});
    }
  }
  selectLocation(form) {
    const id=form.elements.profile.value,old=this.record(this.model.chg.find(g=>String(g.s)===String(this.editor)));
    if(id==="__manual__"){
      form.elements.price.value=old?.profile?.id==="manual"?old.profile.price??"":"";
      form.elements.free.checked=old?.profile?.id==="manual"?!!old.profile.free:false;
      form.querySelector(".cc-advanced").open=true;return;
    }
    const p=this.data.profiles.find(p=>p.id===id);if(!p)return;
    form.elements.price.value=p.price??"";form.elements.free.checked=!!p.free;
    if(form.elements.total&&p.id!==old?.profile?.id)form.elements.total.value="";
  }
  collectProfiles(validate=true) {
    return [...this.editorNode.querySelectorAll(".cc-profile")].map(group=>{
      const old=this.data.profiles[Number(group.dataset.index)],get=n=>group.querySelector('[name="'+n+'"]'),source=get("source").value,entity=get("entity").value.trim(),efficiency=cn(get("efficiency").value)??90;
      if(validate&&!(efficiency>=1&&efficiency<=100))throw Error(T("Efficiency must be between 1 and 100%."));
      if(validate&&!get("free").checked&&source!=="battery"){const unit=this.card._hass.states?.[entity]?.attributes?.unit_of_measurement;if(!(source==="power"?["W","kW"]:["Wh","kWh"]).includes(unit))throw Error(T("Select W/kW for power or Wh/kWh for energy."));}
      return {...old,name:get("name").value.trim().slice(0,60),price:cn(get("price").value),free:get("free").checked,default:get("default").checked,source,entity,efficiency};
    });
  }
  async click(e) {
    const button=e.target.closest("[data-cc]");if(!button)return;e.preventDefault();e.stopPropagation();const action=button.dataset.cc;
    if(this.saving)return;
    if(action==='remove-profile'){
      const group=button.closest('.cc-profile');if(group.querySelector('.cc-delete-confirm'))return;
      const notice=document.createElement('div');notice.className='cc-delete-confirm';notice.setAttribute('role','group');notice.setAttribute('aria-label','Confirm profile deletion');
      notice.innerHTML='<p>'+esc(T("Delete this charging profile? Existing charging sessions and saved costs will be kept."))+'</p><button type="button" class="cc-button" data-cc="remove-cancel">'+esc(T("Cancel"))+'</button> <button type="button" class="cc-button danger" data-cc="remove-confirm">'+esc(T("Delete charging profile"))+'</button>';group.append(notice);notice.querySelector('button').focus();return;
    }
    if(action==='remove-cancel'){button.closest('.cc-delete-confirm').remove();return;}
    if(action==='remove-confirm'){
      const index=Number(button.closest('.cc-profile').dataset.index);this.data.profiles=this.collectProfiles(false);this.data.profiles.splice(index,1);
      this.message=T("Profile removed. Existing charges and saved costs are kept.");this.renderEditor();this.autoSaveProfiles();return;
    }
    if(action==='curve'){

      if(this.dirty){this.message='Save or cancel your changes first.';this.renderEditor();return;}
      const g=this.model?.chg.find(row=>String(row.s)===button.dataset.start);if(!g)return;
      button.disabled=true;
      try{
        const module=await import('/deepal_companion/frontend/charging-curve.js?v=2.0.1-b3&rev=20261127-01');if(!this.host.isConnected)return;
        this.curveDialog?.remove();
        this.curveDialog=module.openCurveDialog(this.host.getRootNode(),this.card._hass,async()=>{
          if(g.id&&!String(g.id).startsWith('recorder_')){const data=await this.card._hass.companionRequest('session_curve',{session_id:g.id});return {...data,mode:data.mode||(typeof g.dc==='boolean'?(g.dc?'DC':'AC'):null)};}
          const series=EN.captureChargingCurve(this.model.curveRaw||{},g);
          return {start:g.s,end:g.e,mode:typeof g.dc==='boolean'?(g.dc?'DC':'AC'):null,series:Object.fromEntries(Object.entries(series).map(([key,rows])=>[key,rows.map(([t,value])=>({lu:t/1000,s:value}))]))};
        },this.card._c);
      }catch(error){this.message=tError(error.message);this.renderEditor();}finally{button.disabled=false;}return;
    }
    if((action==="profiles"&&this.editor==="profiles")||(action==="session"&&this.editor!==null&&String(this.editor)===String(button.dataset.start))){ /* the same opener again closes what it opened, like the close button */
      const profiles=this.editor==='profiles';if(profiles&&this.autoTimer){await this.autoSaveProfiles();}this.cancelChanges();if(profiles){this.editor=null;this.renderEditor();}return;
    }
    if(action==="profiles"||action==="session"){this.editor=action==="profiles"?"profiles":button.dataset.start;this.message="";this.dirty=false;const anchor=action==="session"?(button.closest('.cc-session-row')||button):this.host.querySelector(".cc-summary");if(anchor)anchor.after(this.editorNode);this.renderEditor();return;}
    if(action==="cancel"){this.cancelChanges();return;}
    if(action==="close"){const profiles=this.editor==='profiles';if(profiles&&this.autoTimer){await this.autoSaveProfiles();}this.cancelChanges();if(profiles){this.editor=null;this.renderEditor();}return;}
    if(this.saving)return;
    button.disabled=true;
    try {
      if((action==="save-profiles"||action==="save-session")&&!this.editorNode.querySelector("form").reportValidity())return;
      if(action==="add"){this.data.profiles=this.collectProfiles();if(this.data.profiles.length>=12)throw Error("Maximum 12 locations.");this.data.profiles.push({id:"place_"+Date.now(),name:T("New location"),price:null,free:false,source:"battery",entity:"",efficiency:90});this.dirty=true;this.renderEditor();this.scheduleProfileSave();return;}
      if(action==="save-profiles")this.data.profiles=this.collectProfiles();
      if(action==="save-session"){
        this.manualTotal(this.editorNode.querySelector("form"));
        const form=this.editorNode.querySelector("form"),g=this.model.chg.find(g=>String(g.s)===String(this.editor)),id=form.elements.profile.value,p=id==="__manual__"?{id:"manual",name:"",price:null,free:false,source:"battery",entity:"",efficiency:90}:this.data.profiles.find(p=>p.id===id);
        if(!p||!g)throw Error(T("Choose a location first."));
        if(id==="__manual__"&&!form.elements.free.checked&&cn(form.elements.price.value)===null&&cn(form.elements.total.value)===null)throw Error(T("Enter a price per kWh or a total paid."));
        const previous=this.record(g),{default:_suggested,...snapshot}=previous?.profile?.id===id?previous.profile:p; /* a receipt keeps the price it was saved with, not the suggestion flag */
        if(form.elements.free.checked&&cn(form.elements.total.value)>0)throw Error(T("Leave Total paid empty for a free session."));
        this.data.sessions[String(Math.round(g.s/1000))]={start:g.s,capacity:previous?.capacity||this.ctx.cap,profile:{...snapshot,price:cn(form.elements.price.value),free:form.elements.free.checked},energy:cn(form.elements.energy.value),total:cn(form.elements.total.value)};
      }
      this.saving=true;this.editorNode.querySelectorAll("[data-cc]").forEach(node=>node.disabled=true);
      await this.save();this.dirty=false;await this.history(this.model);this.decorate(this.model,this.ctx);
    } catch(error){this.message=tError(error.message);const status=this.editorNode.querySelector('[role="status"]');if(status){status.hidden=false;status.textContent=this.message;}}
    finally{this.saving=false;button.disabled=false;this.editorNode.querySelectorAll("[data-cc]").forEach(node=>node.disabled=false);}
  }
}

EN.ChargingCosts = ChargingCosts;
EN.styles = PCSS;
const LOAD = () => K.loaderHtml("bolt");
function renderEnergyGraph(m,ctx){
  const clean=series=>series.filter((p,i)=>!(p[1]<=0&&((series[i-1]?.[1]??0)>5||(series[i+1]?.[1]??0)>5))); /* a single 0 % reading between real values is a car glitch, not an empty battery */
  m={...m,batt:clean(m.batt),fuel:clean(m.fuel)};
  const f=(n)=>new Intl.NumberFormat(ctx.lang,{maximumFractionDigits:1}).format(n),fu=m.fuel.length>0&&ctx.hasFuel;
  const W=Math.max(300,Math.min(1440,Number(ctx.chartWidth)||340)),H=W>700?300:W>420?245:215,L=36,R=12,top=26,ph=H-82,bottom=top+ph,track=bottom+17,pw=W-L-R;
  const t0=ctx.zoomRange?.start??m.t0,span=(ctx.zoomRange?.end??energyDayStart(m.nDays,m.timezone,m.t0))-t0,tEnd=Math.min(m.now,t0+span),X=t=>L+(Math.min(Math.max(t,t0),t0+span)-t0)/span*pw;
  const values=m.batt.map(p=>p[1]).concat(fu?m.fuel.map(p=>p[1]):[]),lo=values.length?Math.min(...values):50,ymin=Math.max(0,Math.min(60,Math.floor((lo-5)/10)*10)),Y=v=>top+(100-Math.min(100,Math.max(ymin,v)))/(100-ymin)*ph;
  const ticks=Math.max(3,Math.min(10,Math.floor(pw/85))),every=Math.max(1,Math.ceil(span/86400000/ticks));
  let svg=`<svg class="en-ch" tabindex="0" data-t0="${t0}" data-span="${span}" data-ymin="${ymin}" data-width="${W}" data-left="${L}" data-right="${R}" data-top="${top}" data-height="${ph}" viewBox="0 0 ${W} ${H}" role="img" aria-label="${esc(T(fu ? 'Battery and petrol history' : 'Battery history'))}">`;
  for(const level of [100,Math.round((100+ymin)/2),ymin])svg+=`<line x1="${L}" x2="${W-R}" y1="${Y(level)}" y2="${Y(level)}" stroke="currentColor" stroke-opacity=".13" stroke-dasharray="3 5"/><text x="${L-8}" y="${Y(level)+4}" text-anchor="end" style="font-size:10px">${level}%</text>`;
  m.days.filter(day=>span>=2*86400000&&day.t>=t0&&day.t<t0+span).forEach((day,index)=>{if(index%every===0){const x=X(day.t);svg+=`<line x1="${x}" x2="${x}" y1="${top}" y2="${bottom}" stroke="currentColor" stroke-opacity=".045"/><text x="${Math.min(W-R-20,Math.max(L+18,x))}" y="${H-3}" text-anchor="middle" style="font-size:10px">${esc(ctx.fmt.dm(day.t))}</text>`;}});
  if(span<2*86400000)for(let i=0;i<5;i++){const t=t0+span*i/4;svg+=`<text x="${Math.max(L+16,Math.min(W-R-16,X(t)))}" y="${H-3}" text-anchor="middle" style="font-size:10px">${esc(ctx.fmt.hm(t))}</text>`;}
  if(tEnd<t0+span-60000)svg+=`<rect x="${X(tEnd)}" y="${top}" width="${Math.max(0,W-R-X(tEnd))}" height="${ph}" fill="currentColor" opacity=".025"/>`;
  const labels=[];
  m.chg.filter(g=>g.e>t0&&g.s<t0+span).forEach(g=>{const x=X(g.s),width=Math.max(2,X(g.e)-x);svg+=`<rect x="${x}" y="${top}" width="${width}" height="${ph}" rx="2" fill="${CL_OK}" opacity=".12"/>`;if(g.kwh>0){const text=f(g.kwh),half=text.length*3+4;labels.push({x:Math.min(W-R-half,Math.max(L+half,(X(g.s)+X(g.e))/2)),text,half,value:g.kwh});}});
  const kept=[];for(const label of labels.sort((a,b)=>b.value-a.value)){if(!kept.some(other=>Math.abs(other.x-label.x)<other.half+label.half+8))kept.push(label);}
  for(const label of kept)svg+=`<text x="${label.x}" y="15" text-anchor="middle" style="fill:${CL_OK};font-size:10px;font-weight:600">${esc(label.text)}</text>`;
  const curve=series=>{if(tEnd<t0)return [];const points=[];for(const [t,value]of ramped(series,t0,tEnd)){const x=X(t);if(!points.length||x>points[points.length-1][0]+.01)points.push([x,Y(value)]);}return points;};
  const battery=curve(m.batt);
  if(battery.length>1){const path=mono(battery),last=battery[battery.length-1];svg+=`<path d="${path} L${last[0]} ${bottom} L${battery[0][0]} ${bottom} Z" fill="${CL_OK}" opacity=".09"/><path d="${path}" fill="none" stroke="${CL_OK}" stroke-width="3.25" stroke-linejoin="round" stroke-linecap="round"/><circle cx="${last[0]}" cy="${last[1]}" r="4.5" fill="${CL_OK}" stroke="var(--ds-card,#1b1f27)" stroke-width="2"/>`;}
  if(fu){const petrol=curve(m.fuel);if(petrol.length>1)svg+=`<path d="${mono(petrol)}" fill="none" stroke="${CL_FUEL}" stroke-width="2" stroke-dasharray="6 5" stroke-linejoin="round" stroke-linecap="round"/>`;}
  svg+=`<rect x="${L}" y="${track}" width="${pw}" height="6" rx="3" fill="var(--energy-parked)" opacity=".45"/>`;
  for(const [list,color]of [[m.drv,null],[m.chg,CL_OK]])for(const g of list.filter(g=>g.e>t0&&g.s<t0+span))svg+=`<rect x="${X(g.s)}" y="${track}" width="${Math.max(2,X(g.e)-X(g.s))}" height="6" rx="3" fill="${color||(fu&&g.fuel>0?CL_FUEL:CL_DRV)}"/>`;
  svg+=`<g class="en-cur" visibility="hidden"><line y1="${top}" y2="${track+6}" stroke="var(--ds-fg)" stroke-opacity=".5" stroke-dasharray="3 4"/><circle r="4" cy="0" fill="${CL_OK}" stroke="var(--ds-card,#1b1f27)" stroke-width="2"/></g></svg>`;
  return `<div class="energy-chart-block"><h4>${esc(T('Battery'))}</h4><div class="en-leg"><span><i style="background:${CL_OK}"></i>${esc(T('Charging'))} (kWh)</span><span><i style="background:${CL_DRV}"></i>${esc(T('Driving'))}</span>${fu?`<span><i style="background:${CL_FUEL}"></i>${esc(T('Petrol driving'))}</span>`:''}<span><i style="background:var(--energy-parked)"></i>${esc(T('Parked'))}</span></div><div class="en-cw">${svg}<div class="en-tip" hidden></div></div><p class="hint" style="margin-top:8px">${esc(T('Tap the chart to see the values at that moment.'))}</p></div>`;
}

function view(m, ctx) {
  const { lang, cap, st, hasFuel, now } = ctx, f = (n, d) => new Intl.NumberFormat(lang, { maximumFractionDigits: d, minimumFractionDigits: d }).format(n);
  const hm = (t) => ctx.fmt.hm(t);
  const wd = (t) => ctx.fmt.dm(t);
  const lbl = (t) => { const key=ctx.fmt.dayStart(t);return key===ctx.fmt.dayStart(now)?T("Today"):key===ctx.fmt.dayStart(now,-1)?T("Yesterday"):wd(t); };
  const v = (id) => { const s = st[id]; return s ? s.state : undefined; };
  const bat = (() => { const x = num(v("batt")), g = m.batt.length ? m.batt[m.batt.length - 1][1] : NaN; return (!Number.isFinite(x) || (x === 0 && g > 5)) && Number.isFinite(g) ? g : x; })(), range = num(v("range")), liveSeg = m.chg.find((g) => g.live);
  const acN = num(v("ac")), dcN = num(v("dc")), curA = Math.max(Number.isFinite(acN) ? acN : 0, Number.isFinite(dcN) ? dcN : 0);
  const chgNow = !!liveSeg || curA > CHG_A, on = v("pow") === "on";
  /* 1. current state */
  let h = "";
  const eta = (() => { const mm = /^(\d+):(\d{2})/.exec(String(v("left") || "")); return mm && Number.isFinite(bat) && bat < 100 ? now + (Number(mm[1]) * 60 + Number(mm[2])) * 60e3 : null; })();
  if (!ctx.cur) { /* another week: only the totals and the chart */ } else if (chgNow) {
    h += `<div class="en-now chg"><div class="en-st"><span class="s">${ico("bolt")}${esc(T("Charging"))}</span><small>${esc(liveSeg && liveSeg.dc ? "DC" : "AC")}${curA > 0 ? ` · ${esc(f(curA, 0))} A` : ""}</small></div>
      <div class="en-big"><b>${Number.isFinite(bat) ? esc(f(bat, 0)) + "%" : "–"}</b>${eta ? `<span>${esc(T("Full at {0}", hm(eta)))}</span>` : ""}</div>
      <div class="en-sub">${liveSeg && Number.isFinite(liveSeg.from) ? esc(T("From {0}% at {1}", f(liveSeg.from, 0), hm(liveSeg.s))) : ""}${liveSeg && liveSeg.kwh ? ` · +${esc(f(liveSeg.kwh, 1))} kWh` : ""}</div></div>`;
  } else {
    const last = m.chg.filter((g) => !g.live).slice(-1)[0];
    h += `<div class="en-now"><div class="en-st"><span class="s">${ico(on ? "engine" : "info")}${esc(on ? T("Vehicle on") : T("Parked"))}</span><small>${Number.isFinite(range) ? esc(f(range, 0)) + " km" : ""}</small></div>
      <div class="en-big"><b>${Number.isFinite(bat) ? esc(f(bat, 0)) + "%" : "–"}</b>${hasFuel && Number.isFinite(num(v("fuel"))) ? `<span>${esc(T("Fuel {0}%", f(num(v("fuel")), 0)))}</span>` : ""}</div>
      <div class="en-sub">${last ? esc(T("Last charge: {0} {1} – {2}, {3}% → {4}%", lbl(last.s), hm(last.s), hm(last.e), f(last.from, 0), f(last.to, 0))) + (last.kwh ? ` · <span class="ok-t" style="color:rgb(var(--ds-ac,var(--ds-ok,52,211,153)))">${esc(f(last.kwh, 1))} kWh</span>` : "") : esc(T("No charge in the period shown."))}</div></div>`;
  }
  { /* totals of the period */
    const km = m.days.reduce((a, d) => a + (d.km > 0 ? d.km : 0), 0), kwh = m.chg.reduce((a, g) => a + (g.kwh > 0 ? g.kwh : 0), 0);
    h += `<div class="en-tot"><div>${esc(T("Driving"))}<b>${esc(f(km, 0))} km</b></div><div>${esc(T("Charged"))}<b class="ok">${kwh > 0 ? esc(f(kwh, 1)) + " kWh" : "–"}</b></div><div>${esc(T("Charges"))}<b>${m.chg.length}</b></div></div>`;
  }
  /* 2. curve */
  h += `<div class="en-nav"></div>`;
  const fu = m.fuelUsed && hasFuel, tEnd=m.now;
  h += renderEnergyGraph(m,ctx);
  /* 3. per day: days/values without data show "–", not 0 */
  h += `<div><h4>${esc(T("Per day"))}</h4><div class="en-tb h${fu ? " f4" : ""}"><span>${esc(T("Day"))}</span><span>${esc(T("Km"))}</span><span>${esc(T("Charging"))}</span><span>${esc(T("Battery"))} ↓</span>${fu ? `<span>${esc(T("Petrol"))}</span>` : ""}</div>`;
  m.days.filter((d) => d.t <= tEnd).reverse().forEach((d) => { h += `<div class="en-tb${fu ? " f4" : ""}"><span>${esc(lbl(d.t))}</span><span class="${d.km > 0 ? "" : "z"}">${d.km > 0 ? esc(f(d.km, d.km < 10 ? 1 : 0)) : "–"}</span><span class="${d.n ? "ok" : "z"}">${d.n ? (d.kwh > 0 ? esc(f(d.kwh, 1)) + " kWh" : "✓") : "–"}</span><span class="${d.batteryUsed > 0 ? "bu" : "z"}">${d.batteryUsed > 0 ? "−" + esc(f(d.batteryUsed, 1)) + " kWh" : "–"}</span>${fu ? `<span class="${d.fuel > 0 ? "fu" : "z"}">${d.fuel > 0 ? "−" + esc(f(d.fuel, 1)) + " L" : "–"}</span>` : ""}</div>`; });
  h += "</div>";
  /* 4. charges */
  h += `<div><h4>${esc(T("Charges"))}</h4>`;
  if (!m.chg.length) h += `<p class="hint">${esc(T("No charges in the period shown."))}</p>`;
  m.chg.slice().reverse().forEach((g) => {
    const dur = Math.round((g.e - g.s) / 60e3), dh = dur >= 60 ? `${Math.floor(dur / 60)}${T("h")} ${dur % 60}′` : `${dur}′`;
    const ok = Number.isFinite(g.from) && Number.isFinite(g.to), lo = ok ? Math.min(100, Math.max(0, Math.min(g.from, g.to))) : 0, wd2 = ok ? Math.min(100, Math.max(1, Math.abs(g.to - g.from))) : 0;
    h += `<div class="en-li"><span class="a"><span class="ic">${ico("plug")}</span><span class="mid">${esc(lbl(g.s))} · ${esc(hm(g.s))} – ${esc(g.live ? T("now") : hm(g.e))}<span class="bd">${esc(g.dc ? "DC" : "AC")}</span>${ok ? `<span class="bar"><i style="left:${lo}%;width:${wd2}%"></i></span>` : ""}<small>${ok ? esc(f(g.from, 0)) + " → " + esc(f(g.to, 0)) + "% · " : ""}${esc(dh)}</small></span></span><span class="b">${g.kwh ? esc(f(g.kwh, 1)) + " kWh" : ""}</span></div>`;
  });
  h += `<button type="button" class="en-infotog" data-eninfo aria-expanded="${infoOpen}"><span>${esc(T("How it is calculated"))}</span>${ico(infoOpen ? "chevu" : "chevd")}</button><aside class="en-info"${infoOpen ? "" : " hidden"}><span class="en-info-icon" aria-hidden="true">ⓘ</span><div><p>${esc(T("Battery use: net level drop during drives × {0} kWh capacity.", f(cap, 1)))}</p>${fu ? `<p>${esc(T("Petrol use: fuel drops recorded while driving. No tank size is assumed."))}</p>` : ""}<p>${esc(T("Charging: battery increase × capacity. All figures are estimates; delayed readings and small top-ups may be missed."))}</p><p>${esc(T("History follows Recorder retention. For 30 days, set purge_keep_days: 30 or more."))}</p></div></aside></div>`;

  return h;
}

/* Recover Recorder sessions without fetching the entire Companion session list. */
EN.captureChargingCurve=(raw,session)=>Object.fromEntries([['ac','ac'],['dc','dc'],['battery','batt']].map(([role,key])=>{
  const rows=raw[key]||[],anchor=rows.filter(([t])=>t<=session.s&&t>=session.s-86400000).at(-1),inside=rows.filter(([t])=>t>session.s&&t<=session.e),points=[];
  for(const [t,state]of [...(anchor?[anchor]:[]),...inside]){const n=num(state),value=Number.isFinite(n)&&n>=0?n:null;if(!points.length||points.at(-1)[1]!==value)points.push([t,value]);}
  return [role,points];
}));
EN.importChargeRows=async(hass,rows,checkpoint=false)=>{
  let offset=0,total=0;
  do{let batch=rows.slice(offset,offset+20);while(batch.length>1&&JSON.stringify(batch).length>900000)batch=batch.slice(0,Math.ceil(batch.length/2));
    const end=offset+batch.length,result=await hass.companionRequest('sessions_import',{rows:batch,...(checkpoint?{curve_version:1,sync_complete:end>=rows.length}:{})});total+=result.imported||0;offset=end;
  }while(offset<rows.length);
  return total;
};
EN.syncRecorderCharges=async(card)=>{
  const hass=card._hass,now=Date.now(),cap=card._battKwh?card._battKwh():Number(card._c.battery_kwh)||DEF_KWH;
  const saved=await hass.companionRequest('costs_get',{}),assignments=saved?.value?.sessions||{};
  const ids={batt:K.resolveId(hass,card._c,ENT.batt),ac:K.resolveId(hass,card._c,ENT.ac),dc:K.resolveId(hass,card._c,ENT.dc)};
  const meters=Object.values(assignments).map(r=>r.profile).filter(p=>p?.source!=='battery'&&p?.entity).map(p=>p.entity);
  const entities=[...new Set([...Object.values(ids),...meters])];
  const history=await hass.companionRecorderHistory({type:'history/history_during_period',start_time:new Date(0).toISOString(),end_time:new Date(now).toISOString(),entity_ids:entities,include_start_time_state:false,significant_changes_only:false,minimal_response:true,no_attributes:true});
  const raw={batt:rowsOf(history?.[ids.batt]),ac:rowsOf(history?.[ids.ac]),dc:rowsOf(history?.[ids.dc]),odo:[],pow:[],fuel:[]};
  const rows=model(raw,now,cap,now,0,true).chg.filter(g=>!g.live&&!g.gap&&g.to>g.from).map(g=>{
    const assignment=assignments[String(Math.round(g.s/1000))]||null,entity=assignment?.profile?.entity;
    const pricing=chargingCost(g,assignment,numSeries(rowsOf(history?.[entity])),hass.states?.[entity]?.attributes?.unit_of_measurement||'');
    if(!assignment)pricing.energy=g.kwh;
    return {...g,capacity:cap,origin:'recorder',assignment,pricing,curve:EN.captureChargingCurve(raw,g)};
  });
  const imported=await EN.importChargeRows(hass,rows,true);
  return {imported};
};
/* Preserve recovered completed charges in the independent Companion archive. */
EN.loadChargingSessions=async(card)=>{
  const hass=card._hass,now=Date.now(),cap=card._battKwh?card._battKwh():Number(card._c.battery_kwh)||DEF_KWH;
  const archived=await hass.companionRequest("sessions",{});
  const saved=await hass.companionRequest("costs_get",{}),settings=saved?.value||{},assignments=settings.sessions||{};
  const ids={batt:K.resolveId(hass,card._c,ENT.batt),ac:K.resolveId(hass,card._c,ENT.ac),dc:K.resolveId(hass,card._c,ENT.dc)};
  const meters=Object.values(assignments).map(r=>r.profile).filter(p=>p?.source!=="battery"&&p?.entity).map(p=>p.entity);
  const entities=[...new Set([...Object.values(ids),...meters].filter(Boolean))];
  const key=JSON.stringify([card._companion?.vehicle_id,entities,cap]);
  let history,warning="";
  try{
    if(card._recorderCharges?.key===key&&now-card._recorderCharges.at<300000)history=card._recorderCharges.value;
    else{
      history=await hass.companionRecorderHistory({type:"history/history_during_period",start_time:new Date(0).toISOString(),end_time:new Date(now).toISOString(),entity_ids:entities,include_start_time_state:false,significant_changes_only:false,minimal_response:true,no_attributes:true});
      card._recorderCharges={key,at:now,value:history};
    }
  }catch(_){history={};warning=T("HA Recorder history could not be loaded. Only the Companion archive is shown.");}
  const raw={batt:rowsOf(history?.[ids.batt]),ac:rowsOf(history?.[ids.ac]),dc:rowsOf(history?.[ids.dc]),odo:[],pow:[],fuel:[]};
  const recovered=model(raw,now,cap,now,0,true).chg.filter(g=>!archived.some(a=>a.s<=g.e&&a.e>=g.s)).map(g=>{
    const assignment=assignments[String(Math.round(g.s/1000))]||null,entity=assignment?.profile?.entity;
    const pricing=chargingCost(g,assignment,numSeries(rowsOf(history?.[entity])),hass.states?.[entity]?.attributes?.unit_of_measurement||"");
    if(!assignment)pricing.energy=g.kwh;
    return {...g,id:"recorder_"+Math.round(g.s/1000),capacity:cap,origin:"recorder",assignment,pricing,curve:EN.captureChargingCurve(raw,g)};
  });
  const completed=recovered.filter(row=>!row.live&&!row.gap&&row.to>row.from);
  if(completed.length&&hass.user?.is_admin){
    try{
      await EN.importChargeRows(hass,completed);
      const persisted=await hass.companionRequest('sessions',{});
      return {rows:[...recovered.filter(row=>!persisted.some(a=>a.s<=row.e&&a.e>=row.s)),...persisted].sort((a,b)=>a.s-b.s),warning};
    }catch(error){warning=T("Recovered charges couldn’t be archived and still depend on Recorder history: ")+tError(error.message||String(error));}
  }
  return {rows:[...recovered,...archived].sort((a,b)=>a.s-b.s),warning};
};

function renderChargingChart(sessions,lang="en",now=Date.now(),options={}){
  const count=options.period===7?7:30,dateLabel=t=>options.fmt?.date?options.fmt.date(t):"—",shortDate=t=>options.fmt?.dm?options.fmt.dm(t):"—",heading="Charging · "+count+" days";
  
  if(!sessions.some(row=>!row.live&&row.s<=now))return '<section class="cc-charts cc-chart-empty"><div class="cc-chart-heading">'+esc(heading)+'</div><p class="cc-hint">'+esc(T("No completed charging sessions available for this chart yet."))+'</p></section>';
  const zone=options.fmt?.timeZone,days=[];
  for(let i=count-1;i>=0;i--){const t=energyDayStart(-i,zone,now);days.push({t,energy:0,cost:0,missing:0});}
  for(const row of sessions){
    if(row.live||row.s>now)continue;
    const t=energyDayStart(0,zone,row.s);const day=days.find(x=>x.t===t);if(!day)continue;
    const energy=Number.isFinite(row.pricing?.energy)?row.pricing.energy:row.kwh;
    if(Number.isFinite(energy)&&energy>0)day.energy+=energy;
    if(Number.isFinite(row.pricing?.cost))day.cost+=row.pricing.cost;else day.missing++;
    if(Number.isFinite(row.unpriced_count))day.missing+=row.unpriced_count;
  }
  const fmt=new Intl.NumberFormat(lang,{maximumFractionDigits:2});
  const chart=(key,label,unit,color)=>{
    const max=Math.max(1,...days.map(d=>d[key])),bars=days.map((d,i)=>{
      const height=d[key]/max*80,x=30+i*300/count,y=100-height;
      return '<rect x="'+x+'" y="'+y+'" width="'+Math.max(3,300/count-3)+'" height="'+height+'" rx="2" fill="'+color+'"><title>'+esc(dateLabel(d.t)+': '+fmt.format(d[key])+' '+unit)+'</title></rect>'+(key==="cost"&&d.missing?'<circle cx="'+(x+3.5)+'" cy="108" r="2" fill="var(--energy-fuel)"><title>'+esc(T("Unpriced sessions"))+'</title></circle>':"");
    }).join("");
    return '<div class="cc-chart"><b>'+esc(label)+'</b><svg viewBox="0 0 340 133" role="img" tabindex="0" aria-label="'+esc(label)+'"><title>'+esc(label+' · '+count+" days")+'</title><line x1="27" y1="100" x2="331" y2="100" stroke="currentColor" opacity=".2"/><text x="27" y="14" fill="currentColor" font-size="9">'+esc(fmt.format(max)+' '+unit)+'</text>'+bars+'<text x="30" y="128" fill="currentColor" font-size="9">'+esc(shortDate(days[0].t))+'</text><text x="327" y="128" text-anchor="end" fill="currentColor" font-size="9">'+esc(shortDate(now))+'</text></svg></div>';
  };
  return '<section class="cc-charts" data-cc-series="'+esc(JSON.stringify(days))+'" data-cc-lang="'+esc(lang)+'"><div class="cc-chart-heading">'+esc(heading)+'</div><div class="cc-chart-grid">'+chart("energy",T("Charged energy"),"kWh","var(--energy-charge)")+chart("cost",T("Charging cost"),"€","var(--energy-drive)")+'</div><div class="cc-chart-tip" role="tooltip" hidden></div><small>'+esc(T("Energy may be estimated. Amber dots mark unpriced sessions; they are left out of the cost bars."))+'</small></section>';
}
EN.renderChargingChart=renderChargingChart;
EN.bindChargingChart=(host,haFormat=null)=>{
  for(const root of host.querySelectorAll(".cc-charts")){
    if(!root.dataset.ccSeries)continue;
    if(root._ccBound)continue;root._ccBound=true;
    const days=JSON.parse(root.dataset.ccSeries),lang=root.dataset.ccLang||"en",format=new Intl.NumberFormat(lang,{maximumFractionDigits:2}),tip=root.querySelector(".cc-chart-tip");let index=days.length-1;
    const show=(svg,i)=>{index=Math.max(0,Math.min(days.length-1,i));const day=days[index];if(!day)return;
      tip.textContent=(haFormat?.date?haFormat.date(day.t):"—")+" · "+format.format(day.energy)+" kWh · "+format.format(day.cost)+" €"+(day.missing?" · "+day.missing+" "+T("unpriced"):"");tip.hidden=false;
    };
    const point=event=>{const svg=event.target.closest(".cc-chart svg");if(!svg)return;const box=svg.getBoundingClientRect();show(svg,Math.floor(((event.clientX-box.left)/box.width*340-30)/(300/days.length)));};
    root.addEventListener("pointermove",point);root.addEventListener("pointerdown",point);
    root.addEventListener("pointerleave",()=>{tip.hidden=true;});
    root.addEventListener("focusin",event=>{if(event.target.matches("svg"))show(event.target,index);});
    root.addEventListener("focusout",()=>{tip.hidden=true;});
    root.addEventListener("keydown",event=>{if(event.target.matches("svg")&&["ArrowLeft","ArrowRight"].includes(event.key)){event.preventDefault();show(event.target,index+(event.key==="ArrowRight"?1:-1));}});
  }
};

function renderChargingCosts(m,ctx){
  const rows=m.chg.slice().reverse();
  let html='<div class="en-cost-heading"><h3>'+esc(T("Charging costs"))+'</h3><small>'+rows.length+" "+esc(T("charging sessions"))+'</small></div>';
  html+=renderChargingChart(rows,ctx.lang,ctx.now,{fmt:ctx.fmt});
  if(!rows.length)return html+'<p class="hint">'+esc(T("No charging sessions have been recorded yet."))+'</p>';
  html+='<div class="en-cost-list">';
  for(const g of rows){
    const date=ctx.fmt.dm(g.s)+" · "+ctx.fmt.hm(g.s)+" – "+ctx.fmt.hm(g.e);
    html+='<div class="en-li"><span class="a"><span class="ic">'+ico("plug")+'</span><span class="mid">'+esc(date)+(g.live?' <span class="bd">'+esc(T("Charging"))+'</span>':"")+'<small>'+esc(Number.isFinite(g.from)?(Number.isFinite(g.to)?g.from+"% → "+g.to+"%":g.from+"%"):"")+'</small></span></span><span class="b">'+(g.kwh>0?esc(new Intl.NumberFormat(ctx.lang,{maximumFractionDigits:1}).format(g.kwh))+" kWh":"—")+'</span></div>';
  }
  return html+"</div>";
}

EN.panel = (d, card, options = {}) => {
  let stop = false, timer = 0, busy = false, chartObserver=null, lastChart=null;
  if(card._companion)card._compEnergyHost?.energyCleanup?.();
  let costs;
  d.energyCleanup=()=>{stop=true;clearInterval(timer);chartObserver?.disconnect();costs?.curveDialog?.remove();};
  if(card._companion)card._compEnergyHost=d;
  costs = options.chartOnly ? {ready:Promise.resolve(),dirty:false,history:async()=>{},decorate:()=>{}} : new ChargingCosts(card, d);
  const get = () => card._hass, S = () => (get() && get().states) || {};
  const ids = () => { const o = {}; for (const [k, key] of Object.entries(ENT)) o[k] = K.resolveId(get(), card._c, key); return o; };
  const body = () => d.querySelector(".en-body");
  const empty = (icon, txt, retry) => { const b = body(); if (!b) return; b.innerHTML = `${options.chartOnly?'<div class="en-nav"></div>':''}<div class="en-empty">${ico(icon)}<span>${esc(txt)}</span>${retry ? `<button class="btn sm" data-retry>${esc(T("Retry"))}</button>` : ""}</div>`;if(options.chartOnly)paintNav(get().locale?.language||"en"); };
  let selT = null,chartRange=null;
  /* tap/drag on the chart: vertical line and the values at that moment */
  const bind = (m, ctx) => {
    const b = body(), svg = b && b.querySelector("svg.en-ch"), tip = b && b.querySelector(".en-tip"), cur = svg && svg.querySelector(".en-cur"); if (!svg || !tip || !cur) return;
    const t0 = Number(svg.dataset.t0), span = Number(svg.dataset.span), ymin = Number(svg.dataset.ymin), VW = Number(svg.dataset.width)||340, left=Number(svg.dataset.left)||10, right=Number(svg.dataset.right)||10, top=Number(svg.dataset.top)||12, ph=Number(svg.dataset.height)||96, plotWidth=VW-left-right, f0 = (n) => new Intl.NumberFormat(ctx.lang, { maximumFractionDigits: 0 }).format(n);
    const fmt = { format: (t) => K.haFmt(get()).wdh(t) };
    const show = (t) => {
      if(t0>m.now){tip.hidden=true;return;}t = Math.min(m.now,t0+span, Math.max(t0, t)); selT = t;
      const bv = at(m.batt, t), fv = m.fuel.length ? at(m.fuel, t) : NaN, vx = left + (t - t0) / span * plotWidth;
      const chg = m.chg.find((g) => t >= g.s && t <= (g.live ? ctx.now : g.e)), drv = !chg && m.drv.find((g) => t >= g.s && t <= g.e);
      const stx = chg ? [CL_OK, T("Charging") + " " + (chg.dc ? "DC" : "AC")] : drv ? (drv.fuel > 0 ? [CL_FUEL, T("Petrol driving")] : [CL_DRV, T("Driving")]) : ["var(--ds-fg2)", T("Parked")];
      cur.setAttribute("visibility", "visible"); const ln = cur.querySelector("line"), dt = cur.querySelector("circle");
      ln.setAttribute("x1", vx.toFixed(1)); ln.setAttribute("x2", vx.toFixed(1)); dt.setAttribute("cx", vx.toFixed(1));
      dt.setAttribute("cy", (top + (100 - Math.min(100, Math.max(ymin, bv))) / (100 - ymin) * ph).toFixed(1));
      tip.hidden = false;
      tip.innerHTML = `<b>${esc(fmt.format(t))}</b><i style="background:${stx[0]}"></i>${esc(stx[1])}<br>${esc(T("Battery"))} ${Number.isFinite(bv) ? esc(f0(bv)) + "%" : "–"}${ctx.hasFuel && Number.isFinite(fv) ? `<br>${esc(T("Petrol"))} ${esc(f0(fv))}%` : ""}`;
      const w = svg.getBoundingClientRect().width || 1, px = vx / VW * w; tip.style.left = px < w / 2 ? "auto" : "6px"; tip.style.right = px < w / 2 ? "6px" : "auto";
    };
    const at_ = (e) => { const r = svg.getBoundingClientRect(); return t0 + ((e.clientX - r.left) / r.width * VW - left) / plotWidth * span; };
    let down = false;
    svg.addEventListener("keydown",e=>{if(["ArrowLeft","ArrowRight"].includes(e.key)){e.preventDefault();show((selT??m.now)+(e.key==="ArrowRight"?1:-1)*span/100);}});
    svg.addEventListener("pointerdown", (e) => { down = true; show(at_(e)); });
    svg.addEventListener("pointermove", (e) => { if (down || e.pointerType === "mouse") show(at_(e)); });
    const up = () => { down = false; }; svg.addEventListener("pointerup", up); svg.addEventListener("pointercancel", up);
    svg.addEventListener("pointerleave", (e) => { if (e.pointerType === "mouse" && !down) { cur.setAttribute("visibility", "hidden"); tip.hidden = true; selT = null; } });
    const wrapper=svg.parentElement;
    if(!wrapper._dcChartZoom)wrapper._dcChartZoom=window.__DEEPAL_COMPANION_UI.mountChartZoom(wrapper,()=>({start:m.t0,end:energyDayStart(m.nDays,m.timezone,m.t0)}),range=>{chartRange=range;ctx.zoomRange=range;const template=document.createElement('template');template.innerHTML=renderEnergyGraph(m,ctx);wrapper.innerHTML=template.content.querySelector('.en-cw').innerHTML;bind(m,ctx);},{minSpan:3600000,initial:chartRange,controlsHost:wrapper.parentElement.querySelector('.en-leg')});
    if (selT !== null) show(selT);
  };
  let off = 0, period = 7, reqId = 0, limitT = null;
  let costView=false,lastEnergyModel=null;
  if(options.chartOnly)period=7;
  /* 7-day windows ending today (not Monday–Sunday): always full days; offset -1 = the 7 days before */
  const zone=()=>K.haFmt(get()).timeZone;
  const wkStart = (o,now=Date.now()) => energyDayStart(-(period-1)+o*period,zone(),now);
  const wkEnd = (o,now=Date.now()) => energyDayStart(1+o*period,zone(),now);
  const paintNav = (lang) => {
    const n = d.querySelector(".en-nav"); if (!n) return;
    const now=Date.now(),t0=wkStart(off,now),t1=wkEnd(off,now)-1, fm = { format: (t) => K.haFmt(get()).dm(t) };
    const noPrev = !options.chartOnly && limitT !== null && limitT > t0, days = limitT !== null ? Math.max(1, Math.round((Date.now() - limitT) / 86400000)) : 0;
    const limitNote = days === 1 ? "Recorder limit: history goes back about 1 day." : "Recorder limit: history goes back about {0} days.";
    const pillSnap = window.__DEEPAL_COMPANION_UI?.pillSnap?.(n); n.innerHTML = `<div class="seg" role="group" aria-label="${esc(T("Period"))}"><button data-period="7" data-k="period" class="${period === 7 ? "on" : ""}" aria-pressed="${period === 7}">${esc(T("Weekly"))}</button><button data-period="30" data-k="period" class="${period === 30 ? "on" : ""}" aria-pressed="${period === 30}">${esc(T("Monthly"))}</button></div><div class="en-dates"><button class="btn" data-wk="-1" aria-label="${esc(T("Previous period"))}"${noPrev ? " disabled" : ""}>${ico("chevl")}</button><div class="en-wk"><b>${esc(fm.format(t0))} – ${esc(fm.format(t1))}</b><small>${esc(T(off === 0 ? "Last {0} days" : "{0}-day period", period))}</small></div><button class="btn" data-wk="1" aria-label="${esc(T("Next period"))}"${off >= 0 ? " disabled" : ""}>${ico("chevr")}</button></div>${noPrev ? `<p class="hint en-lim">${esc(T(limitNote, days))}</p>` : ""}`;
    window.__DEEPAL_COMPANION_UI?.pillApply?.(n,pillSnap);

  };
  const startPeriodLoading = () => {
    const b=body();if(!b)return;b.style.minHeight=b.getBoundingClientRect().height+'px';b.classList.add('is-period-loading');b.setAttribute('aria-busy','true');
    b.querySelectorAll('.en-period-loader,.en-load-error').forEach(node=>node.remove());
    const target=b.querySelector('.en-cw')||b,loader=document.createElement('div');loader.className='en-period-loader';loader.setAttribute('role','status');loader.setAttribute('aria-label',T('Loading history'));loader.innerHTML=LOAD();target.append(loader);
  };
  const run = async (first, force) => {
    if (stop || !get() || costs.dirty || (busy && !force)) return; busy = true; const my = ++reqId;
    try {
      await costs.ready;
      const hass = get(), st = S(), id = ids(), real = Date.now(), cfg = card._c || {}, cap = card._battKwh ? card._battKwh() : (Number(cfg.battery_kwh) > 0 ? Number(cfg.battery_kwh) : DEF_KWH);
      if(costView&&hass.companionRequest){
        await costs.load();
        const available=await EN.loadChargingSessions(card),archived=available.rows;
        if(my!==reqId||stop)return;
        const charges=archived;
        const m={chg:charges,days:[],t0:charges.length?charges[0].s:real,now:real};
        const ctx={cap,lang:hass.locale?.language||hass.language||"en",fmt:K.haFmt(hass),now:real};
        costs.archiveOnly=true;
        body().innerHTML=renderChargingCosts(m,ctx);costs.decorate(m,ctx);
        if(available.warning){const note=document.createElement("p");note.className="cc-info";note.textContent=available.warning;body().prepend(note);}
        return;
      }
      costs.archiveOnly=false;

      const t0 = wkStart(off,real), tEnd = Math.min(real,wkEnd(off,real)), cur = off === 0, lang = (hass.locale && hass.locale.language) || hass.language || "en";
      paintNav(lang);
      if(options.chartOnly)d.dispatchEvent(new CustomEvent('energy-period',{detail:{start:t0,end:tEnd,period},bubbles:true}));
      if (!st[id.batt]) { empty("info", T("Battery sensor not found. Check the prefix in Settings → Vehicle.")); return; }
      const fuelOn = card._hasFuel ? card._hasFuel() : cfg.powertrain !== "ev"; /* an electric car has no fuel data to load or draw */
      const want = ["batt", "ac", "dc", "odo", "pow", "fuel", "volume"].filter((k) => st[id[k]] && (fuelOn || (k !== "fuel" && k !== "volume")));
      let res;
      try {
        res = await hass.callWS({ type: "history/history_during_period", start_time: new Date(t0).toISOString(), end_time: new Date(tEnd).toISOString(), entity_ids: want.map((k) => id[k]), include_start_time_state: true, significant_changes_only: false, minimal_response: true, no_attributes: true });
      } catch (_) { if (my === reqId){if(!body().querySelector('.en-now'))empty("alert", T("Couldn't load history from Home Assistant."), true);else{const note=document.createElement('p');note.className='en-load-error';note.textContent=T("Couldn't load history from Home Assistant.");body().querySelector('.en-nav')?.after(note);}}return; }
      if (my !== reqId) return;
      const raw = {}; for (const k of ["batt", "ac", "dc", "odo", "pow", "fuel", "volume"]) raw[k] = rowsOf(res && res[id[k]]);
      const volumeUnit=st[id.volume]?.attributes?.unit_of_measurement;
      if(!['L','l','litre','liter','litres','liters'].includes(volumeUnit))raw.volume=[];
      /* recorder limit: if the data starts inside the week (or is missing) there is no older history */
      const fr = raw.batt.length ? raw.batt[0][0] : null;
      if (fr === null) { if (limitT === null) limitT = tEnd; } else if (fr > t0 + 5 * 60e3) limitT = limitT === null ? fr : Math.min(limitT, fr);
      paintNav(lang);
      const m = model(raw, tEnd, cap, t0, period, cur, K.haFmt(hass).timeZone);
      if (hass.companionRequest) {
        const archiveRows = await hass.companionRequest("sessions", {
          start_time: new Date(t0).toISOString(), end_time: new Date(tEnd).toISOString()
        }).catch(() => []);
        const archived = archiveRows.filter(g => g.e - g.s >= MIN_CHG);
        // Preserve older Recorder sessions and prefer canonical backend records on overlap.
        m.chg = [
          ...m.chg.filter(g => !archived.some(a => a.s <= g.e && a.e >= g.s)),
          ...archived
        ].sort((a,b)=>a.s-b.s);
        for (const day of m.days) { day.n=0; day.kwh=0; }
        for (const charge of m.chg) {
          const day=m.days.find(d=>d.key===dayKey(charge.s,m.timezone));
          if(day){day.n++;if(charge.kwh>0)day.kwh+=charge.kwh;}
        }
      }
m.curveRaw=raw;
      if (!m.hasData) { empty("info", T("No battery history yet. The Home Assistant recorder must record it.")); return; }
      const ctx = { zoomRange:chartRange,chartWidth: Math.round(body()?.clientWidth||340), fmt: K.haFmt(hass), lang, cap, cur, st: Object.fromEntries(Object.keys(ENT).map((k) => [k, st[id[k]]])), hasFuel: fuelOn && !!st[id.fuel], now: real };
      await costs.history(m);
      if (my !== reqId || costs.dirty || stop) return;
      ctx.chartWidth=Math.round(body()?.clientWidth||340);
      lastChart={m,ctx};
      if(options.chartOnly){
        const template=document.createElement("template");template.innerHTML=view(m,ctx);
        const chart=template.content.querySelector(".en-cw")?.parentElement;
        if(chart){body().replaceChildren(chart);body().insertAdjacentHTML("afterbegin",'<div class="en-nav"></div>');paintNav(lang);bind(m,ctx);}else empty("info",T("No battery history yet. The Home Assistant recorder must record it."));
        return;
      }
      lastEnergyModel=m;
      body().innerHTML = view(m, ctx); paintNav(lang); bind(m, ctx); costs.decorate(m, ctx);
    } finally { if (my === reqId){busy = false;const b=body();if(b){b.querySelectorAll('.en-period-loader').forEach(node=>node.remove());b.classList.remove('is-period-loading');b.removeAttribute('aria-busy');b.style.minHeight='';}resizeChart();} }
  };
  d.classList.add("enpanel");
  d.innerHTML = `<style>${PCSS}</style><div class="en-body"><div class="en-nav"></div>${LOAD()}</div>`;
  infoOpen = false;
  if(get()?.companionRequest&&!options.chartOnly){
    const tabs=document.createElement("div");tabs.className="en-cost-tabs";
    tabs.innerHTML='<button data-en-mode="energy" aria-pressed="true">'+esc(T("Energy"))+'</button><button data-en-mode="costs" aria-pressed="false">'+esc(T("Charging costs"))+'</button>';
    d.insertBefore(tabs,body());
    if(card._compOpenCosts){card._compOpenCosts=false;costView=true;tabs.querySelectorAll("button").forEach(n=>n.setAttribute("aria-pressed",String(n.dataset.enMode==="costs")));}
    tabs.addEventListener("click",event=>{
      const button=event.target.closest("[data-en-mode]");if(!button)return;
      if(costs.dirty){costs.message=T("Save or close the location editor first.");const status=costs.editorNode?.querySelector("[role=status]");if(status){status.hidden=false;status.textContent=costs.message;}return;}
      costView=button.dataset.enMode==="costs";
      tabs.querySelectorAll("button").forEach(n=>n.setAttribute("aria-pressed",String(n===button)));
      body().innerHTML=LOAD();run(true,true);
    });
  }

  d.addEventListener("click", (e) => {
    if (e.target.closest("[data-cc]")) return;
    const tog = e.target.closest("[data-eninfo]");
    if (tog) { infoOpen = !infoOpen; tog.setAttribute("aria-expanded", String(infoOpen)); const box = d.querySelector(".en-info"); if (box) box.hidden = !infoOpen; const ic0 = tog.querySelector(".i"); if (ic0) ic0.outerHTML = ico(infoOpen ? "chevu" : "chevd"); return; }
    const p = e.target.closest("[data-period]");
    if (costs.dirty && e.target.closest("[data-period],[data-wk]")) { const status = d.querySelector(".cc-editor [role=status]"); if (status) status.textContent = T("Save or close the editor before changing dates."); return; }
    if (p && Number(p.dataset.period) !== period) { period = Number(p.dataset.period); off = 0; selT = null;chartRange=null; startPeriodLoading();run(true, true); return; }
    const w = e.target.closest("[data-wk]");
    if (w && !w.disabled) { off = Math.min(0, off + Number(w.dataset.wk)); selT = null;chartRange=null; startPeriodLoading();run(true, true); return; }
    if (e.target.closest("[data-retry]")) { body().innerHTML = '<div class="en-nav"></div>' + LOAD(); run(true, true); }
  });
  run(true);
  const resizeChart=()=>{
    if(stop||busy||!d.isConnected||!lastChart||costs.dirty||!body()?.querySelector('svg.en-ch'))return;
    const width=Math.round(body().clientWidth||340);if(Math.abs(width-lastChart.ctx.chartWidth)<8)return;
    const {m,ctx}=lastChart;ctx.chartWidth=width;
    if(options.chartOnly){const template=document.createElement('template');template.innerHTML=view(m,ctx);const chart=template.content.querySelector('.energy-chart-block');if(chart){body().replaceChildren(chart);body().insertAdjacentHTML("afterbegin",'<div class="en-nav"></div>');paintNav(ctx.lang);}}
    else{body().innerHTML=view(m,ctx);paintNav(ctx.lang);costs.decorate(m,ctx);}
    bind(m,ctx);
  };chartObserver=new ResizeObserver(resizeChart);chartObserver.observe(d);
  timer = setInterval(() => { if (!d.isConnected) { stop = true; clearInterval(timer); return; } if (costView || off === 0) run(false); }, 120000);
};
/* Optional module translations (English source keys) — taken by the card's I18N through addExtra */
EN.lang = {};
EN.ready = false;
EN.init = (ctx) => { K = ctx; EN.ready = true; };
EN.model = model; EN.chargeSegments = chargeSegments; EN.driveSegments = driveSegments; EN.rowsOf = rowsOf;
})();

